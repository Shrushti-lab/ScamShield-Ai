"""
ScamShield AI - Machine Learning Engine & Optimization Pipeline
Feature Extraction, Metaheuristic Grey Wolf Optimizer (GWO), and Random Forest Classifier.
"""

import math
import re
from typing import Dict, List, Tuple, Any, Optional
from urllib.parse import urlparse
from pathlib import Path
import numpy as np

# Try importing ML dependencies; provide graceful fallbacks if loading early
try:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import matthews_corrcoef
    import joblib
except ImportError:
    RandomForestClassifier = None
    matthews_corrcoef = None
    joblib = None


TARGET_BRANDS: List[str] = [
    "paypal", "amazon", "facebook", "telegram", "apple",
    "binance", "chase", "netflix", "dhl", "coinbase",
    "microsoft", "google", "wellsfargo", "bankofamerica"
]

SUSPICIOUS_TLDS: set = {
    ".xyz", ".top", ".tk", ".buzz", ".club", ".work",
    ".click", ".gq", ".cf", ".ml", ".ga", ".fit", ".rest",
    ".live", ".monster", ".country", ".surf", ".stream", ".icu"
}

SUSPICIOUS_KEYWORDS: List[str] = [
    "verify", "wallet", "claim", "login", "bank", "secure",
    "airdrop", "confirm", "update", "signin", "account",
    "auth", "recover", "reward", "bonus", "free", "gift",
    "validation", "security", "web3", "connect"
]

FEATURE_NAMES: List[str] = [
    "url_length",
    "domain_length",
    "domain_shannon_entropy",
    "subdomain_depth",
    "is_ip_address",
    "punycode_flag",
    "symbol_ratio",
    "digit_ratio",
    "suspicious_tld_score",
    "min_levenshtein_brand",
    "brand_with_hyphen_flag",
    "path_depth",
    "query_length",
    "suspicious_keyword_flag",
    "has_custom_port",
    "double_slash_redirect"
]


def calculate_shannon_entropy(string: str) -> float:
    """Calculates Shannon Entropy: H = -sum(p * log2(p))."""
    if not string:
        return 0.0
    length = float(len(string))
    char_counts: Dict[str, int] = {}
    for char in string:
        char_counts[char] = char_counts.get(char, 0) + 1
    
    entropy = 0.0
    for count in char_counts.values():
        p = count / length
        entropy -= p * math.log2(p)
    return float(entropy)


def levenshtein_distance(s1: str, s2: str) -> int:
    """Computes Levenshtein edit distance between two strings using dynamic programming."""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]


def safe_hostname(url: str) -> str:
    """Returns the lower-cased hostname of a URL, or '' if it cannot be parsed."""
    cleaned = url.strip()
    if not cleaned.startswith(("http://", "https://")):
        cleaned = "http://" + cleaned
    try:
        return (urlparse(cleaned).hostname or "").lower()
    except ValueError:
        return re.sub(r"^https?://", "", cleaned).split("/")[0].split(":")[0].lower()


_SECOND_LEVEL = {"co", "com", "org", "net", "ac", "gov", "edu"}


def hostname_label_for_typo(url: str) -> str:
    labels = safe_hostname(url).split(".")
    return labels[-2] if len(labels) >= 2 else ""


def brand_impersonation(hostname: str) -> bool:
    """True when a target brand appears in the host but the registrable domain is not that brand's own."""
    labels = hostname.split(".")
    if len(labels) < 2:
        return False
    # amazon.co.uk -> registrable label is 'amazon', not 'co'
    if len(labels) >= 3 and labels[-2] in _SECOND_LEVEL and len(labels[-1]) == 2:
        registrable, leading = labels[-3], ".".join(labels[:-3])
    else:
        registrable, leading = labels[-2], ".".join(labels[:-2])
    for brand in TARGET_BRANDS:
        if registrable == brand:
            continue
        if brand in leading:
            return True
    return False


def extract_url_features(url: str) -> np.ndarray:
    """
    Extracts 16 cybersecurity features from a given URL:
    1. url_length
    2. domain_length
    3. domain_shannon_entropy
    4. subdomain_depth
    5. is_ip_address
    6. punycode_flag
    7. symbol_ratio
    8. digit_ratio
    9. suspicious_tld_score
    10. min_levenshtein_brand
    11. brand_with_hyphen_flag
    12. path_depth
    13. query_length
    14. suspicious_keyword_flag
    15. has_custom_port
    16. double_slash_redirect
    """
    cleaned_url = url.strip()
    if not cleaned_url.startswith(("http://", "https://")):
        cleaned_url = "http://" + cleaned_url

    try:
        parsed = urlparse(cleaned_url)
        hostname = parsed.hostname.lower() if parsed.hostname else ""
        port = parsed.port  # may raise ValueError for out-of-range ports
    except ValueError:
        # Malformed URL (bad port / broken IPv6 literal): fall back to a crude split
        parsed = urlparse("http://invalid.invalid/")
        hostname = re.sub(r"^https?://", "", cleaned_url).split("/")[0].split(":")[0].lower()
        port = None
    path = parsed.path
    query = parsed.query

    # 1. URL Length
    url_length = float(len(cleaned_url))

    # 2. Domain Length
    domain_length = float(len(hostname))

    # 3. Domain Shannon Entropy
    domain_entropy = calculate_shannon_entropy(hostname)

    # 4. Subdomain Depth
    host_parts = hostname.split(".")
    if len(host_parts) > 2:
        subdomain_depth = float(len(host_parts) - 2)
    else:
        subdomain_depth = 0.0

    # 5. Is IP Address (IPv4 / IPv6)
    ipv4_pattern = r"^(\d{1,3}\.){3}\d{1,3}$"
    ipv6_pattern = r"^[0-9a-fA-F:]+$"
    is_ip = 1.0 if (re.match(ipv4_pattern, hostname) or (":" in hostname and re.match(ipv6_pattern, hostname))) else 0.0

    # 6. Punycode Flag (xn--)
    punycode_flag = 1.0 if "xn--" in hostname else 0.0

    # 7. Symbol Ratio
    num_symbols = sum(1 for c in cleaned_url if not c.isalnum() and c not in [":", "/", "."])
    symbol_ratio = float(num_symbols / max(len(cleaned_url), 1))

    # 8. Digit Ratio
    num_digits = sum(1 for c in cleaned_url if c.isdigit())
    digit_ratio = float(num_digits / max(len(cleaned_url), 1))

    # 9. Suspicious TLD Score
    tld_match = any(hostname.endswith(tld) for tld in SUSPICIOUS_TLDS)
    suspicious_tld_score = 1.0 if tld_match else 0.0

    # Extract primary label for brand comparison (e.g. 'paypal-update' from 'paypal-update.xyz')
    domain_labels = hostname.split(".")
    primary_label = domain_labels[-2] if len(domain_labels) >= 2 else (domain_labels[0] if domain_labels else "")

    # 10. Min Levenshtein Brand Distance
    min_lev = 99
    for brand in TARGET_BRANDS:
        dist = levenshtein_distance(primary_label, brand)
        if dist < min_lev:
            min_lev = dist
    min_levenshtein_brand = float(min_lev)

    # 11. Brand with Hyphen Flag (e.g., paypal-secure, amazon-verify)
    brand_hyphen = 0.0
    for brand in TARGET_BRANDS:
        if f"{brand}-" in hostname or f"-{brand}" in hostname or f"{brand}-" in path:
            brand_hyphen = 1.0
            break
    brand_with_hyphen_flag = brand_hyphen

    # 12. Path Depth
    path_segments = [p for p in path.split("/") if p]
    path_depth = float(len(path_segments))

    # 13. Query Length
    query_length = float(len(query))

    # 14. Suspicious Keyword Flag
    found_keyword = any(kw in cleaned_url.lower() for kw in SUSPICIOUS_KEYWORDS)
    suspicious_keyword_flag = 1.0 if found_keyword else 0.0

    # 15. Has Custom Port
    has_custom_port = 0.0
    if port and port not in [80, 443]:
        has_custom_port = 1.0

    # 16. Double Slash Redirect in Path
    double_slash_redirect = 1.0 if "//" in path else 0.0

    features = np.array([
        url_length,
        domain_length,
        domain_entropy,
        subdomain_depth,
        is_ip,
        punycode_flag,
        symbol_ratio,
        digit_ratio,
        suspicious_tld_score,
        min_levenshtein_brand,
        brand_with_hyphen_flag,
        path_depth,
        query_length,
        suspicious_keyword_flag,
        has_custom_port,
        double_slash_redirect
    ], dtype=np.float64)

    return features


class GreyWolfOptimizer:
    """
    Grey Wolf Optimizer (GWO) metaheuristic algorithm for hyperparameter optimization.
    Simulates hunting hierarchy (Alpha, Beta, Delta, Omega) of grey wolves.
    
    Optimizes Random Forest hyper-parameters:
    - Dimension 0: n_estimators in [50, 300]
    - Dimension 1: max_depth in [5, 30]
    - Dimension 2: min_samples_split in [2, 10]
    
    Fitness Function: Matthews Correlation Coefficient (MCC)
    """

    def __init__(
        self,
        n_wolves: int = 12,
        max_iter: int = 10,
        lower_bounds: Optional[np.ndarray] = None,
        upper_bounds: Optional[np.ndarray] = None,
        random_state: int = 42
    ):
        self.n_wolves = n_wolves
        self.max_iter = max_iter
        # Bounds: [n_estimators, max_depth, min_samples_split]
        self.lb = lower_bounds if lower_bounds is not None else np.array([50.0, 5.0, 2.0])
        self.ub = upper_bounds if upper_bounds is not None else np.array([300.0, 30.0, 10.0])
        self.dim = len(self.lb)
        self.random_state = random_state
        self.rng = np.random.RandomState(random_state)

        # Leader wolves
        self.alpha_pos = np.zeros(self.dim)
        self.alpha_score = -float("inf")

        self.beta_pos = np.zeros(self.dim)
        self.beta_score = -float("inf")

        self.delta_pos = np.zeros(self.dim)
        self.delta_score = -float("inf")

        self.convergence_history: List[float] = []

    def _decode_params(self, position: np.ndarray) -> Dict[str, int]:
        """Maps continuous position vector to discrete integer Random Forest hyperparameters."""
        n_estimators = int(np.clip(np.round(position[0]), self.lb[0], self.ub[0]))
        max_depth = int(np.clip(np.round(position[1]), self.lb[1], self.ub[1]))
        min_samples_split = int(np.clip(np.round(position[2]), self.lb[2], self.ub[2]))
        return {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "min_samples_split": min_samples_split
        }

    def _evaluate_fitness(
        self,
        position: np.ndarray,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: np.ndarray,
        y_val: np.ndarray
    ) -> float:
        """Calculates Matthews Correlation Coefficient (MCC) for hyperparameter vector."""
        params = self._decode_params(position)
        rf = RandomForestClassifier(
            n_estimators=params["n_estimators"],
            max_depth=params["max_depth"],
            min_samples_split=params["min_samples_split"],
            random_state=self.random_state,
            n_jobs=-1
        )
        rf.fit(X_train, y_train)
        y_pred = rf.predict(X_val)

        # Compute MCC
        mcc = float(matthews_corrcoef(y_val, y_pred))
        # Handle nan edge case if constant predictions
        if np.isnan(mcc):
            mcc = -1.0
        return mcc

    def optimize(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: np.ndarray,
        y_val: np.ndarray
    ) -> Tuple[Dict[str, int], float]:
        """
        Executes GWO iterations to locate optimal Random Forest hyperparameters.
        Returns: (best_params_dict, best_mcc_score)
        """
        # Initialize wolf population uniformly between lower and upper bounds
        positions = self.rng.uniform(
            low=self.lb,
            high=self.ub,
            size=(self.n_wolves, self.dim)
        )

        for iteration in range(self.max_iter):
            # Evaluate fitness of each wolf
            for i in range(self.n_wolves):
                # Ensure bounds
                positions[i] = np.clip(positions[i], self.lb, self.ub)
                fitness = self._evaluate_fitness(positions[i], X_train, y_train, X_val, y_val)

                # Update Alpha, Beta, Delta based on fitness
                if fitness > self.alpha_score:
                    self.delta_score = self.beta_score
                    self.delta_pos = self.beta_pos.copy()

                    self.beta_score = self.alpha_score
                    self.beta_pos = self.alpha_pos.copy()

                    self.alpha_score = fitness
                    self.alpha_pos = positions[i].copy()
                elif fitness > self.beta_score:
                    self.delta_score = self.beta_score
                    self.delta_pos = self.beta_pos.copy()

                    self.beta_score = fitness
                    self.beta_pos = positions[i].copy()
                elif fitness > self.delta_score:
                    self.delta_score = fitness
                    self.delta_pos = positions[i].copy()

            self.convergence_history.append(self.alpha_score)

            # Parameter 'a' linearly decreases from 2 to 0
            a = 2.0 - 2.0 * (float(iteration) / float(self.max_iter))

            # Update position of each wolf
            for i in range(self.n_wolves):
                for j in range(self.dim):
                    # Hunting equations relative to Alpha
                    r1 = self.rng.rand()
                    r2 = self.rng.rand()
                    A1 = 2.0 * a * r1 - a
                    C1 = 2.0 * r2
                    D_alpha = abs(C1 * self.alpha_pos[j] - positions[i, j])
                    X1 = self.alpha_pos[j] - A1 * D_alpha

                    # Hunting equations relative to Beta
                    r1 = self.rng.rand()
                    r2 = self.rng.rand()
                    A2 = 2.0 * a * r1 - a
                    C2 = 2.0 * r2
                    D_beta = abs(C2 * self.beta_pos[j] - positions[i, j])
                    X2 = self.beta_pos[j] - A2 * D_beta

                    # Hunting equations relative to Delta
                    r1 = self.rng.rand()
                    r2 = self.rng.rand()
                    A3 = 2.0 * a * r1 - a
                    C3 = 2.0 * r2
                    D_delta = abs(C3 * self.delta_pos[j] - positions[i, j])
                    X3 = self.delta_pos[j] - A3 * D_delta

                    # Collective consensus update
                    positions[i, j] = (X1 + X2 + X3) / 3.0

                positions[i] = np.clip(positions[i], self.lb, self.ub)

        best_params = self._decode_params(self.alpha_pos)
        return best_params, self.alpha_score


class URLClassifier:
    """
    High-performance URL Classifier utilizing GWO-optimized Random Forest.
    Includes feature explainability, threat scoring (0-100), and heuristic fallback.
    """

    def __init__(self, model_path: Optional[str] = None):
        self.model_path = model_path or str(Path(__file__).parent / "models" / "rf_model.joblib")
        self.model = None
        self.loaded_from_disk = False
        self.metrics: Dict[str, Any] = {}
        self.load_model()

    def load_model(self) -> bool:
        """Loads trained model weights or initializes a robust pre-calibrated model."""
        if joblib and Path(self.model_path).exists():
            try:
                loaded = joblib.load(self.model_path)
                if isinstance(loaded, dict) and "model" in loaded:
                    self.model = loaded["model"]
                    self.metrics = loaded.get("metrics", {})
                else:
                    self.model = loaded
                self.loaded_from_disk = True
                return True
            except Exception as e:
                print(f"[ScamShield AI] Warning: Failed to load model from {self.model_path}: {e}")

        # If model file does not exist yet, initialize a fallback model trained on a lightweight baseline
        self._initialize_fallback_model()
        return False

    def _initialize_fallback_model(self):
        """Creates and calibrates a robust baseline Random Forest model."""
        if RandomForestClassifier is None:
            return

        # Seed with diverse prototypical feature samples (Benign vs Phishing)
        X_proto = np.array([
            # Benign: Google, Amazon, Paypal official, Wikipedia, GitHub
            [22, 10, 2.7, 0, 0, 0, 0.15, 0.0, 0, 10, 0, 0, 0, 0, 0, 0],
            [26, 10, 2.9, 0, 0, 0, 0.14, 0.0, 0, 10, 0, 1, 0, 0, 0, 0],
            [24, 10, 2.8, 0, 0, 0, 0.15, 0.0, 0, 0, 0, 1, 0, 0, 0, 0],
            [35, 13, 3.1, 1, 0, 0, 0.16, 0.0, 0, 9, 0, 2, 5, 0, 0, 0],
            [28, 10, 2.9, 0, 0, 0, 0.15, 0.0, 0, 8, 0, 1, 0, 0, 0, 0],
            # Malicious: Brand spoofing, High entropy, IP hosts, Suspicious TLDs, OTP lures
            [85, 28, 4.3, 3, 0, 0, 0.28, 0.15, 1, 1, 1, 3, 40, 1, 0, 0],
            [92, 34, 4.5, 4, 1, 0, 0.32, 0.25, 1, 2, 1, 4, 30, 1, 1, 1],
            [68, 24, 4.1, 2, 0, 1, 0.29, 0.12, 1, 1, 1, 2, 20, 1, 0, 0],
            [110, 42, 4.7, 5, 0, 0, 0.35, 0.20, 1, 1, 1, 5, 55, 1, 1, 1],
            [75, 29, 4.2, 2, 0, 0, 0.30, 0.18, 1, 1, 1, 3, 25, 1, 0, 0]
        ], dtype=np.float64)
        y_proto = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1], dtype=np.int32)

        self.model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
        self.model.fit(X_proto, y_proto)

    def predict(self, url: str) -> Dict[str, Any]:
        """
        Extracts features, runs inference, and returns comprehensive risk assessment.
        """
        feats = extract_url_features(url)
        features_dict = {name: float(val) for name, val in zip(FEATURE_NAMES, feats)}

        # Domain level indicators
        entropy = features_dict["domain_shannon_entropy"]
        is_ip = features_dict["is_ip_address"] == 1.0
        is_puny = features_dict["punycode_flag"] == 1.0
        tld_flag = features_dict["suspicious_tld_score"] == 1.0
        hyphen_brand = features_dict["brand_with_hyphen_flag"] == 1.0
        min_lev = features_dict["min_levenshtein_brand"]
        has_kw = features_dict["suspicious_keyword_flag"] == 1.0
        custom_port = features_dict["has_custom_port"] == 1.0
        double_slash = features_dict["double_slash_redirect"] == 1.0

        impersonation = brand_impersonation(safe_hostname(url))

        risk_factors: List[str] = []
        if impersonation and not hyphen_brand:
            risk_factors.append("Brand name used inside a domain that does not belong to that brand.")
        if is_ip:
            risk_factors.append("Direct IP address hosting detected (bypasses DNS reputation).")
        if is_puny:
            risk_factors.append("Punycode homoglyph detected (visual deception attack).")
        if tld_flag:
            risk_factors.append("High-risk top-level domain frequently associated with abuse.")
        if hyphen_brand:
            risk_factors.append("Brand name combined with deceptive hyphenated token.")
        elif min_lev == 1:
            risk_factors.append("Typosquatting alert: 1 edit distance from top financial/e-commerce brand.")
        if entropy > 3.8:
            risk_factors.append(f"Abnormally high domain Shannon entropy ({entropy:.2f}), indicates algorithmic generation.")
        if has_kw:
            risk_factors.append("Suspicious credential or financial lure keywords found in URL.")
        if custom_port:
            risk_factors.append("Non-standard web port identified.")
        if double_slash:
            risk_factors.append("Path double-slash redirect evasion detected.")

        # ML Inference
        if self.model is not None:
            feats_2d = feats.reshape(1, -1)
            prob_phishing = float(self.model.predict_proba(feats_2d)[0][1])
        else:
            # Mathematical rule-based fallback if ML engine is cold
            heuristic_score = (
                (25 if is_ip else 0) +
                (25 if is_puny else 0) +
                (20 if tld_flag else 0) +
                (25 if hyphen_brand else 0) +
                (20 if min_lev == 1 else 0) +
                (15 if entropy > 3.8 else 0) +
                (15 if has_kw else 0) +
                (10 if custom_port else 0) +
                (10 if double_slash else 0)
            )
            prob_phishing = min(heuristic_score / 100.0, 1.0)

        threat_score = round(prob_phishing * 100.0, 1)

        # Apply hard overrides for confirmed malicious structural combinations
        if (is_puny or hyphen_brand or impersonation or (min_lev == 1 and (tld_flag or has_kw))) and threat_score < 75.0:
            threat_score = 85.0
            prob_phishing = 0.85

        # A single-character edit of a major brand name (e.g. paypa1.com) is a strong typosquat signal
        if min_lev == 1 and len(hostname_label_for_typo(url)) >= 6 and threat_score < 65.0:
            threat_score = 65.0
            prob_phishing = 0.65
            if not any("Typosquatting" in r for r in risk_factors):
                risk_factors.append("Typosquatting alert: 1 edit distance from top financial/e-commerce brand.")

        is_phishing = threat_score >= 60.0

        if threat_score >= 80.0:
            advisory = "CRITICAL: Do NOT enter credentials or payment data. Strong indicators of phishing or spoofing."
        elif threat_score >= 50.0:
            advisory = "WARNING: Suspicious characteristics detected. Verify the SSL certificate and official domain."
        else:
            advisory = "SECURE: No deceptive structural patterns detected in the destination URL."

        return {
            "url": url,
            "is_phishing": is_phishing,
            "threat_score": threat_score,
            "confidence": round(max(prob_phishing, 1.0 - prob_phishing), 3),
            "entropy": round(entropy, 3),
            "risk_factors": risk_factors,
            "features": features_dict,
            "advisory": advisory
        }
