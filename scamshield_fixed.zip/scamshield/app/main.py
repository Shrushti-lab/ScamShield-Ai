"""
ScamShield AI - Enterprise Threat Interceptor FastAPI Service
High-throughput REST API with LRU Caching, CORS, and Pydantic v2 Schemas.
"""

import time
import json
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Dict, List, Any, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from app.ml_engine import URLClassifier
from app.nlp_heuristics import analyze_chat_message, analyze_marketplace_listing

# -----------------------------------------------------------------------------
# LRU Cache Implementation for High-Throughput URL & Domain Lookups
# -----------------------------------------------------------------------------
class DomainLRUCache:
    """Thread-safe, high-speed OrderedDict LRU cache with hit/miss telemetry."""

    def __init__(self, capacity: int = 2048):
        self.capacity = capacity
        self.cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self.hits = 0
        self.misses = 0
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        normalized = key.strip().lower()
        with self._lock:
            if normalized in self.cache:
                self.cache.move_to_end(normalized)
                self.hits += 1
                return self.cache[normalized]
            self.misses += 1
            return None

    def put(self, key: str, value: Dict[str, Any]) -> None:
        normalized = key.strip().lower()
        with self._lock:
            if normalized in self.cache:
                self.cache.move_to_end(normalized)
            self.cache[normalized] = value
            if len(self.cache) > self.capacity:
                self.cache.popitem(last=False)

    def clear(self) -> None:
        with self._lock:
            self.cache.clear()
            self.hits = 0
            self.misses = 0

    @property
    def size(self) -> int:
        return len(self.cache)


# Global Service Instances
START_TIME = time.time()
url_cache = DomainLRUCache(capacity=4096)
classifier = URLClassifier()

app = FastAPI(
    title="ScamShield AI API",
    description="Enterprise Machine Learning & NLP Fraud Detection API for Browser Interception",
    version="1.0.0"
)

# Permissive CORS for Chrome Extension content scripts and local dashboards
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# -----------------------------------------------------------------------------
# Pydantic v2 Request / Response Schemas
# -----------------------------------------------------------------------------
class URLScanRequest(BaseModel):
    url: str = Field(..., description="Target URL to inspect", min_length=1, max_length=2048)

class URLScanResponse(BaseModel):
    url: str
    is_phishing: bool
    threat_score: float
    confidence: float
    entropy: float
    risk_factors: List[str]
    features: Dict[str, float]
    advisory: str
    cached: bool = False
    latency_ms: float

class ChatScanRequest(BaseModel):
    text: str = Field(..., description="Message text to analyze", min_length=1, max_length=5000)
    platform: Optional[str] = Field("generic", description="Source platform (telegram, messenger, marketplace, generic)")

class ThreatVectorDetail(BaseModel):
    vector: str
    score: float
    description: str
    indicators: List[str]

class ChatScanResponse(BaseModel):
    text: str
    platform: str
    threat_score: float
    threat_level: str
    detected_vectors: List[ThreatVectorDetail]
    flagged_phrases: List[str]
    vector_count: int
    advisory: str

class MarketplaceScanRequest(BaseModel):
    account_age_months: int = Field(12, ge=0, description="Age of seller account in months")
    price: float = Field(..., ge=0.0, description="Listing price in USD")
    market_avg: float = Field(..., ge=0.0, description="Estimated fair market price in USD")
    description: str = Field("", description="Full text description of the listing", max_length=5000)
    ships_only: bool = Field(False, description="Whether listing forces shipping and disallows in-person pickup")

class MarketplaceScanResponse(BaseModel):
    risk_score: float
    threat_level: str
    price_deviation_pct: float
    seller_account_age_months: int
    anomalies: List[str]
    recommendation: str
    nlp_text_breakdown: Dict[str, Any]

class BenchmarkMetric(BaseModel):
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    mcc: float

class ModelMetricsResponse(BaseModel):
    timestamp: str
    status: str
    benchmarks: Dict[str, BenchmarkMetric]
    optimal_hyperparameters: Dict[str, Any]

class HealthResponse(BaseModel):
    status: str
    uptime_seconds: float
    model_loaded: bool
    cache_size: int
    cache_hits: int
    cache_misses: int
    version: str


# -----------------------------------------------------------------------------
# API Endpoints
# -----------------------------------------------------------------------------
@app.get("/api/v1/health", response_model=HealthResponse)
def get_health():
    """Returns real-time health, uptime, and cache telemetry."""
    return HealthResponse(
        status="HEALTHY",
        uptime_seconds=round(time.time() - START_TIME, 2),
        model_loaded=classifier.loaded_from_disk,
        cache_size=url_cache.size,
        cache_hits=url_cache.hits,
        cache_misses=url_cache.misses,
        version="1.0.0"
    )


@app.post("/api/v1/scan-url", response_model=URLScanResponse)
def scan_url(payload: URLScanRequest):
    """
    Analyzes URL through feature extraction and GWO-tuned Random Forest.
    Cached lookups respond in under 1ms.
    """
    start = time.perf_counter()
    url = payload.url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="URL cannot be empty")

    cached_result = url_cache.get(url)
    if cached_result:
        latency = (time.perf_counter() - start) * 1000.0
        cached_copy = cached_result.copy()
        cached_copy["cached"] = True
        cached_copy["latency_ms"] = round(latency, 2)
        return URLScanResponse(**cached_copy)

    # Perform fresh inference
    try:
        prediction = classifier.predict(url)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Inference pipeline error: {str(e)}")

    latency = (time.perf_counter() - start) * 1000.0
    result_data = {
        **prediction,
        "cached": False,
        "latency_ms": round(latency, 2)
    }

    # Store in LRU cache
    url_cache.put(url, result_data)

    return URLScanResponse(**result_data)


@app.post("/api/v1/scan-chat", response_model=ChatScanResponse)
def scan_chat(payload: ChatScanRequest):
    """
    Evaluates chat message contents across OTP, Off-Platform Payment,
    Urgency/Coercion, and Crypto fraud vectors.
    """
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Chat message cannot be empty")

    analysis = analyze_chat_message(text=text, platform=payload.platform or "generic")
    return ChatScanResponse(**analysis)


@app.post("/api/v1/scan-marketplace", response_model=MarketplaceScanResponse)
def scan_marketplace(payload: MarketplaceScanRequest):
    """
    Analyzes Facebook Marketplace listing against pricing anomalies,
    seller account tenure, courier pretexts, and description triggers.
    """
    analysis = analyze_marketplace_listing(
        account_age_months=payload.account_age_months,
        price=payload.price,
        market_avg=payload.market_avg,
        description=payload.description,
        ships_only=payload.ships_only
    )
    return MarketplaceScanResponse(**analysis)


@app.get("/api/v1/model-metrics", response_model=ModelMetricsResponse)
def get_model_metrics():
    """
    Returns comparative evaluation benchmarks: GWO-RF vs Linear SVM vs Decision Tree.
    """
    metrics_path = Path(__file__).parent / "models" / "metrics.json"
    if metrics_path.exists():
        try:
            with open(metrics_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return ModelMetricsResponse(**data)
        except Exception as e:
            print(f"[ScamShield AI] Warning reading metrics.json: {e}")

    raise HTTPException(status_code=503, detail="Model metrics unavailable. Run scripts/train_model.py to generate them.")


@app.post("/api/v1/clear-cache")
def clear_cache():
    """Flushes the in-memory LRU cache."""
    url_cache.clear()
    return {"message": "Cache successfully cleared", "cache_size": 0}


@app.get("/test_sandbox.html")
@app.get("/sandbox")
def get_sandbox():
    """Serves the ScamShield visual test sandbox UI."""
    sandbox_path = Path(__file__).resolve().parent.parent / "test_sandbox.html"
    if not sandbox_path.exists():
        raise HTTPException(status_code=404, detail="test_sandbox.html not found")
    return FileResponse(sandbox_path, media_type="text/html")

