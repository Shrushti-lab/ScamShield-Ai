"""
ScamShield AI - Threat Intelligence & NLP Heuristic Engine
Specialized detection rules for Facebook Marketplace, Telegram Web, and Messaging fraud vectors.
"""

import re
from typing import Dict, List, Any


# -----------------------------------------------------------------------------
# Vector 1: Verification Code / OTP Scams
# -----------------------------------------------------------------------------
OTP_PATTERNS = [
    (r"\b(?:google\s*voice|g-code|verification\s*code|6[\s-]?digit\s*(?:code|pin)?|pin\s*code|security\s*code)\b", 45, "Explicit OTP / Verification code lure"),
    (r"\b(?:send\s*me\s*the\s*code|share\s*the\s*code|tell\s*me\s*the\s*code|give\s*me\s*the\s*pin|what\s*code\s*did\s*you\s*get|send\s*(?:the\s*)?code\s*now)\b", 45, "Direct code exfiltration attempt"),
    (r"\b(?:prove\s*you(?:'re|\s*are)\s*real|confirm\s*you(?:'re|\s*are)\s*real|verify\s*you\s*are\s*human|to\s*make\s*sure\s*you(?:'re|\s*are)\s*legit)\b", 35, "Social engineering identity challenge pretext"),
    (r"\b(?:i\s*just\s*sent\s*(?:you\s*)?a\s*code|check\s*your\s*messages\s*for\s*(?:a\s*)?code|sent\s*a\s*(?:6[\s-]?digit\s*)?code)\b", 40, "Code delivery notification trigger"),
    (r"(?:code|pin|otp)\D{0,15}\b\d{6}\b|\b\d{6}\b\D{0,15}(?:code|pin|otp)", 30, "6-digit numeric token next to code/PIN wording")
]

# -----------------------------------------------------------------------------
# Vector 2: Off-Platform Payment Pivots & Courier Traps
# -----------------------------------------------------------------------------
PAYMENT_PIVOT_PATTERNS = [
    (r"\b(?:zelle|venmo|cashapp|cash\s*app|chime|apple\s*pay|western\s*union|moneygram)\b", 45, "Off-platform non-refundable payment channel requested"),
    (r"\b(?:gift\s*cards?|ebay\s*card|apple\s*gift\s*card|steam\s*card|razer\s*gold)\b", 50, "Untraceable gift card payment demand"),
    (r"\b(?:wire\s*transfer|bank\s*wire|direct\s*deposit|crypto\s*escrow)\b", 45, "Irreversible wire transfer request"),
    (r"\b(?:my\s*(?:son|daughter|brother|cousin|agent|driver)\s*will\s*(?:pick|collect))\b", 40, "Third-party courier / family proxy pickup story"),
    (r"\b(?:pay\s*(?:in\s*advance|upfront|extra)|add\s*\$?\d+\s*for\s*(?:shipping|gas|trouble)|overpay|courier\s*fee)\b", 45, "Overpayment / courier shipping fee check fraud"),
    (r"\b(?:email\s*my|message\s*my|contact\s*my)\s*[\w\.-]+@[\w\.-]+\b", 35, "Off-platform email diversion"),
    (r"\b(?:business\s*account\s*upgrade|pending\s*deposit|funds\s*on\s*hold\s*until\s*fee)\b", 50, "Fake payment confirmation / upgrade fee trap")
]

# -----------------------------------------------------------------------------
# Vector 3: Urgency & Financial Coercion
# -----------------------------------------------------------------------------
URGENCY_PATTERNS = [
    (r"\b(?:account\s*(?:has\s*been\s*)?(?:suspended|frozen|restricted|locked|terminated|disabled))\b", 45, "Account compromise / suspension pretext"),
    (r"\b(?:within\s*(?:15|30|60)\s*minutes|within\s*24\s*hours|act\s*now|urgent\s*action|urgent(?:ly)?\s*(?:need|required|verify|response))\b", 30, "Artificial countdown urgency timer"),
    (r"\b(?:legal\s*action\s*(?:will|against)|court\s*summons|arrest\s*warrant|fbi\s*(?:agent|notice|investigation)|police\s*(?:report|complaint)\s*(?:will|has))\b", 50, "Legal and law enforcement coercion"),
    (r"\b(?:unauthorized\s*(?:access|transaction|charge)|security\s*breach|compromised)\b", 40, "Panic-inducing security breach alert"),
    (r"\b(?:failure\s*to\s*comply|penalties\s*will\s*apply|final\s*notice|funds\s*(?:are\s*)?forfeited)\b", 40, "Consequence intimidation lure")
]

# -----------------------------------------------------------------------------
# Vector 4: Crypto & Task Investment Fraud (Telegram / Web)
# -----------------------------------------------------------------------------
CRYPTO_TASK_PATTERNS = [
    (r"\b(?:daily\s*(?:roi|profit|return|income)|guaranteed\s*(?:profit|returns|payout))\b", 50, "Unrealistic guaranteed daily returns"),
    (r"\b(?:recharge\s*usdt|deposit\s*(?:usdt|btc|eth)|send\s*to\s*wallet|seed\s*phrase)\b", 50, "Direct cryptocurrency deposit / seed phrase request"),
    (r"\b(?:vip\s*signals?|pump\s*and\s*dump|insider\s*signals?|100x\s*gem|moonshot)\b", 45, "Fraudulent trading group / pump-and-dump signal"),
    (r"\b(?:task\s*bonus|hotel\s*review\s*job|youtube\s*like\s*job|earn\s*\$?\d{2,4}\s*(?:per|a)\s*day)\b", 45, "Deceptive task rating / brush click fraud"),
    (r"\b(?:double\s*your\s*(?:money|crypto|deposit)|airdrop\s*claim|connect\s*web3\s*wallet)\b", 50, "Wallet-drainer phishing lure")
]


def analyze_chat_message(text: str, platform: str = "generic") -> Dict[str, Any]:
    """
    Evaluates chat message contents across 4 specialized threat vectors.
    Returns composite threat score, detected vectors, flagged indicators, and advisory.
    """
    cleaned = text.strip()
    lower_text = cleaned.lower()

    detected_vectors: List[Dict[str, Any]] = []
    flagged_phrases: List[str] = []

    # 1. OTP / Verification Code vector
    otp_score = 0.0
    otp_flags = []
    for pattern, weight, desc in OTP_PATTERNS:
        matches = re.findall(pattern, lower_text)
        if matches:
            otp_score += weight
            otp_flags.append(desc)
            flagged_phrases.extend([m if isinstance(m, str) else m[0] for m in matches if m])
    if otp_score > 0:
        capped_otp = min(otp_score, 100.0)
        detected_vectors.append({
            "vector": "OTP_VERIFICATION_THEFT",
            "score": round(capped_otp, 1),
            "description": "Attempting to harvest 2FA/SMS/Google Voice verification codes to hijack accounts.",
            "indicators": otp_flags
        })

    # 2. Off-platform payment pivot vector
    pivot_score = 0.0
    pivot_flags = []
    for pattern, weight, desc in PAYMENT_PIVOT_PATTERNS:
        matches = re.findall(pattern, lower_text)
        if matches:
            pivot_score += weight
            pivot_flags.append(desc)
            flagged_phrases.extend([m if isinstance(m, str) else m[0] for m in matches if m])
    if pivot_score > 0:
        capped_pivot = min(pivot_score, 100.0)
        detected_vectors.append({
            "vector": "OFF_PLATFORM_PAYMENT_PIVOT",
            "score": round(capped_pivot, 1),
            "description": "Steering transactions away from platform buyer-protection towards non-refundable channels or fake courier pickups.",
            "indicators": pivot_flags
        })

    # 3. Urgency / Financial Coercion vector
    urgency_score = 0.0
    urgency_flags = []
    for pattern, weight, desc in URGENCY_PATTERNS:
        matches = re.findall(pattern, lower_text)
        if matches:
            urgency_score += weight
            urgency_flags.append(desc)
            flagged_phrases.extend([m if isinstance(m, str) else m[0] for m in matches if m])
    if urgency_score > 0:
        capped_urgency = min(urgency_score, 100.0)
        detected_vectors.append({
            "vector": "URGENCY_COERCION",
            "score": round(capped_urgency, 1),
            "description": "Manipulating emotional state using imminent deadlines, account freeze threats, or fake legal peril.",
            "indicators": urgency_flags
        })

    # 4. Crypto / Task Investment Fraud vector
    crypto_score = 0.0
    crypto_flags = []
    for pattern, weight, desc in CRYPTO_TASK_PATTERNS:
        matches = re.findall(pattern, lower_text)
        if matches:
            crypto_score += weight
            crypto_flags.append(desc)
            flagged_phrases.extend([m if isinstance(m, str) else m[0] for m in matches if m])
    if crypto_score > 0:
        capped_crypto = min(crypto_score, 100.0)
        detected_vectors.append({
            "vector": "CRYPTO_TASK_FRAUD",
            "score": round(capped_crypto, 1),
            "description": "Offering impossible guaranteed returns, fake task commissions, or wallet-drainer connect links.",
            "indicators": crypto_flags
        })

    # Composite Threat Calculation:
    # High-severity vectors anchor the threat score; multi-vector presence amplifies danger.
    if detected_vectors:
        vector_scores = [v["score"] for v in detected_vectors]
        max_vector_score = max(vector_scores)
        remaining_scores = [s for s in vector_scores if s != max_vector_score]
        compounding_bonus = sum(s * 0.25 for s in remaining_scores)
        final_score = round(min(max_vector_score + compounding_bonus, 100.0), 1)
    else:
        final_score = 0.0

    # Determine Threat Level
    if final_score >= 80.0:
        threat_level = "CRITICAL"
        advisory = "HIGH THREAT: Do NOT comply, send codes, or execute payments. Immediately block and report this sender."
    elif final_score >= 50.0:
        threat_level = "HIGH_RISK"
        advisory = "SUSPICIOUS ACTIVITY: Unsolicited payment or verification requests detected. Keep all communication strictly on-platform."
    elif final_score >= 25.0:
        threat_level = "SUSPICIOUS"
        advisory = "PROCEED WITH CAUTION: Message contains urgency or external payment indicators. Verify sender identity."
    else:
        threat_level = "CLEAN"
        advisory = "NORMAL: No coercive or deceptive social engineering triggers matched."

    vector_count = len(detected_vectors)

    return {
        "text": text,
        "platform": platform,
        "threat_score": final_score,
        "threat_level": threat_level,
        "detected_vectors": detected_vectors,
        "flagged_phrases": list(set(flagged_phrases)),
        "vector_count": vector_count,
        "advisory": advisory
    }


def analyze_marketplace_listing(
    account_age_months: int,
    price: float,
    market_avg: float,
    description: str,
    ships_only: bool = False
) -> Dict[str, Any]:
    """
    Evaluates Facebook Marketplace listings combining economic pricing anomalies,
    seller tenure risk, shipping restrictions, and NLP text heuristics.
    """
    risk_points = 0.0
    anomalies: List[str] = []

    # 1. Pricing Anomaly Analysis
    price_deviation_pct = 0.0
    if market_avg > 0 and price >= 0:
        if price < market_avg:
            price_deviation_pct = round(((market_avg - price) / market_avg) * 100.0, 1)
            if price_deviation_pct >= 60.0:
                risk_points += 35.0
                anomalies.append(f"Severe price anomaly: Listed at {price_deviation_pct}% below estimated market average (${price:,.2f} vs ${market_avg:,.2f}).")
            elif price_deviation_pct >= 40.0:
                risk_points += 20.0
                anomalies.append(f"Suspiciously low price: {price_deviation_pct}% under market.")
        elif price == 0:
            risk_points += 15.0
            anomalies.append("Free / $0 listing lure used to initiate off-platform contact.")

    # 2. Seller Account Age Risk
    if account_age_months < 1:
        risk_points += 30.0
        anomalies.append("Brand new burner account created less than 30 days ago.")
    elif account_age_months < 3:
        risk_points += 20.0
        anomalies.append(f"New seller account tenure ({account_age_months} months). High risk of disposable identity.")
    elif account_age_months < 6:
        risk_points += 10.0

    # 3. Shipping Only Constraint
    if ships_only:
        risk_points += 20.0
        anomalies.append("Shipping-only enforced on local classifieds; refuses in-person inspection or cash on pickup.")

    # 4. Description NLP Scanning
    chat_eval = analyze_chat_message(description, platform="facebook_marketplace")
    for vector in chat_eval["detected_vectors"]:
        risk_points += vector["score"] * 0.35
        anomalies.append(f"Listing text trigger: {vector['vector']} ({', '.join(vector['indicators'])})")

    # Courier stories in description
    courier_match = re.search(r"\b(?:my\s*(?:son|daughter|husband|agent|courier)\s*will\s*pick\s*up|fedex\s*delivery|dhl\s*envelope)\b", description.lower())
    if courier_match:
        risk_points += 25.0
        anomalies.append("Classic third-party courier pickup pretext identified in description.")

    final_risk = round(min(risk_points, 100.0), 1)

    if final_risk >= 75.0:
        threat_level = "CRITICAL"
        recommendation = "HIGH FRAUD PROBABILITY: Do not wire deposit, buy gift cards, or accept third-party courier pickups. Inspect in person and pay cash only."
    elif final_risk >= 50.0:
        threat_level = "HIGH_RISK"
        recommendation = "CAUTION: Listing displays multiple known marketplace scam patterns (low price, new account, or non-local shipping)."
    elif final_risk >= 25.0:
        threat_level = "SUSPICIOUS"
        recommendation = "MODERATE RISK: Verify seller identity and insist on safe public meetup for exchange."
    else:
        threat_level = "CLEAN"
        recommendation = "LOW RISK: Listing pricing and seller profile match normal marketplace benchmarks."

    return {
        "risk_score": final_risk,
        "threat_level": threat_level,
        "price_deviation_pct": price_deviation_pct,
        "seller_account_age_months": account_age_months,
        "anomalies": anomalies,
        "recommendation": recommendation,
        "nlp_text_breakdown": chat_eval
    }
