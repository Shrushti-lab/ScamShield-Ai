"""
ScamShield AI - Enterprise Security & Threat Interception Engine
"""

__version__ = "1.0.0"
