"""
ScamShield AI - Model Training & GWO Hyperparameter Optimization Pipeline
Trains Decision Tree, Linear SVM, and GWO-tuned Random Forest.
Generates an ASCII benchmark report matrix and exports serialized models.
"""

import sys
import json
import time
from pathlib import Path
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef
import joblib

# Ensure repository root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.ml_engine import extract_url_features, GreyWolfOptimizer, FEATURE_NAMES
from scripts.build_dataset import generate_url_dataset, generate_chat_dataset, DATA_DIR


def load_or_generate_dataset() -> tuple:
    csv_path = DATA_DIR / "url_dataset.csv"
    if not csv_path.exists():
        print("[ScamShield AI] Dataset not found. Generating synthetic dataset...")
        records = generate_url_dataset(num_samples=4200)
        import csv
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["url", "label"])
            writer.writeheader()
            writer.writerows(records)

    print(f"[ScamShield AI] Loading dataset from {csv_path}...")
    import csv
    urls: list = []
    labels: list = []
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            urls.append(row["url"])
            labels.append(int(row["label"]))
    return urls, np.array(labels, dtype=np.int32)


def evaluate_model(clf, X_test: np.ndarray, y_test: np.ndarray) -> dict:
    y_pred = clf.predict(X_test)
    return {
        "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
        "precision": round(float(precision_score(y_test, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, y_pred, zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_test, y_pred, zero_division=0)), 4),
        "mcc": round(float(matthews_corrcoef(y_test, y_pred)), 4)
    }


def print_ascii_table(metrics: dict, gwo_params: dict, train_time_gwo: float):
    print("\n" + "=" * 80)
    print("                     SCAMSHIELD AI - MODEL BENCHMARK MATRIX")
    print("=" * 80)
    print(f"{'Classifier':<24} | {'Accuracy':<10} | {'Precision':<10} | {'Recall':<10} | {'F1 Score':<10} | {'MCC':<8}")
    print("-" * 80)
    for model_name, m in metrics.items():
        print(f"{model_name:<24} | {m['accuracy']:<10.4f} | {m['precision']:<10.4f} | {m['recall']:<10.4f} | {m['f1_score']:<10.4f} | {m['mcc']:<8.4f}")
    print("=" * 80)
    print(" [GWO] GREY WOLF OPTIMIZER CONVERGENCE SUMMARY:")
    print(f"  - Optimal n_estimators    : {gwo_params['n_estimators']}")
    print(f"  - Optimal max_depth       : {gwo_params['max_depth']}")
    print(f"  - Optimal min_samples_split: {gwo_params['min_samples_split']}")
    print(f"  - Optimization Time        : {train_time_gwo:.2f}s")
    print("=" * 80 + "\n")


def main():
    urls, y = load_or_generate_dataset()
    print(f"[ScamShield AI] Extracting {len(FEATURE_NAMES)} features across {len(urls)} URLs...")
    start_feat = time.time()
    X_list = [extract_url_features(u) for u in urls]
    X = np.array(X_list, dtype=np.float64)
    print(f"[ScamShield AI] Feature extraction completed in {time.time() - start_feat:.2f}s. Shape: {X.shape}")

    # Train / Validation / Test split (70% train, 15% val, 15% test)
    X_train_full, X_test, y_train_full, y_test = train_test_split(
        X, y, test_size=0.15, random_state=42, stratify=y
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_full, y_train_full, test_size=0.1765, random_state=42, stratify=y_train_full
    )

    print(f"[ScamShield AI] Splits -> Train: {X_train.shape[0]}, Val: {X_val.shape[0]}, Test: {X_test.shape[0]}")

    results = {}

    # 1. Baseline Decision Tree
    print("\n[ScamShield AI] Training Baseline: Decision Tree...")
    dt = DecisionTreeClassifier(max_depth=12, random_state=42)
    dt.fit(X_train_full, y_train_full)
    results["Decision_Tree"] = evaluate_model(dt, X_test, y_test)

    # 2. Baseline Linear SVM
    print("[ScamShield AI] Training Baseline: Linear SVM...")
    svm = LinearSVC(dual="auto", max_iter=2000, random_state=42)
    svm.fit(X_train_full, y_train_full)
    results["Linear_SVM"] = evaluate_model(svm, X_test, y_test)

    # 3. Custom Grey Wolf Optimizer for Random Forest
    print("\n[ScamShield AI] Running Grey Wolf Optimizer (GWO) hyperparameter search...")
    print("  -> Search Boundaries: n_estimators in [50, 300], max_depth in [5, 30], min_samples_split in [2, 10]")
    print("  -> Fitness Function: Matthews Correlation Coefficient (MCC)")

    start_gwo = time.time()
    gwo = GreyWolfOptimizer(n_wolves=10, max_iter=8, random_state=42)
    best_params, best_mcc = gwo.optimize(X_train, y_train, X_val, y_val)
    gwo_duration = time.time() - start_gwo

    print(f"[ScamShield AI] GWO search completed in {gwo_duration:.2f}s. Best Validation MCC: {best_mcc:.4f}")
    print(f"[ScamShield AI] Selected Hyperparameters: {best_params}")

    # Train final Random Forest with GWO-discovered hyperparameters
    print("[ScamShield AI] Training Final Random Forest on combined Train+Val set...")
    rf_best = RandomForestClassifier(
        n_estimators=best_params["n_estimators"],
        max_depth=best_params["max_depth"],
        min_samples_split=best_params["min_samples_split"],
        random_state=42,
        n_jobs=-1
    )
    rf_best.fit(X_train_full, y_train_full)
    results["GWO_Random_Forest"] = evaluate_model(rf_best, X_test, y_test)

    # Print ASCII Report
    print_ascii_table(results, best_params, gwo_duration)

    # Serialize Model Artifact
    models_dir = PROJECT_ROOT / "app" / "models"
    models_dir.mkdir(parents=True, exist_ok=True)
    model_save_path = models_dir / "rf_model.joblib"
    metrics_save_path = models_dir / "metrics.json"

    export_payload = {
        "model": rf_best,
        "features": FEATURE_NAMES,
        "metrics": results["GWO_Random_Forest"],
        "hyperparameters": best_params
    }
    joblib.dump(export_payload, model_save_path)
    print(f"[ScamShield AI] Serialized model saved to {model_save_path}")

    metrics_payload = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "status": "GWO_OPTIMIZED",
        "benchmarks": results,
        "optimal_hyperparameters": {
            "optimizer": "Grey Wolf Optimizer (GWO)",
            **best_params,
            "mcc_fitness": best_mcc
        }
    }
    with open(metrics_save_path, "w", encoding="utf-8") as f:
        json.dump(metrics_payload, f, indent=2)
    print(f"[ScamShield AI] Exported benchmark metrics to {metrics_save_path}")


if __name__ == "__main__":
    main()
