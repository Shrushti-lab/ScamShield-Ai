"""
ScamShield AI - Automated Integration Test Suite
Validates all REST endpoints, ML inference accuracy, heuristics detection, and LRU cache speed.
"""

import sys
from pathlib import Path
import pytest
from starlette.testclient import TestClient

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.main import app, classifier

client = TestClient(app)


def test_health_endpoint():
    """Validates health check returns healthy status and active ML model."""
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "HEALTHY"
    assert data["model_loaded"] is True
    assert "uptime_seconds" in data
    assert "version" in data


def test_scan_url_benign():
    """Validates legitimate domain returns clean safety profile."""
    response = client.post("/api/v1/scan-url", json={"url": "https://www.google.com/search?q=cybersecurity"})
    assert response.status_code == 200
    data = response.json()
    assert data["is_phishing"] is False
    assert data["threat_score"] < 35.0
    assert "SECURE" in data["advisory"]
    assert "features" in data
    assert len(data["features"]) == 16


def test_scan_url_phishing_deceptive():
    """Validates multi-anomaly phishing URL triggers critical alert."""
    payload = {"url": "http://paypal-security-verification.xyz/login.php?user=claim&auth=token"}
    response = client.post("/api/v1/scan-url", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["is_phishing"] is True
    assert data["threat_score"] >= 70.0
    assert len(data["risk_factors"]) >= 2
    # Verify specific indicators caught
    factors_str = " ".join(data["risk_factors"]).lower()
    assert "tld" in factors_str or "brand" in factors_str or "keyword" in factors_str


def test_scan_url_punycode_homoglyph():
    """Validates punycode homoglyph visual spoof is flagged."""
    payload = {"url": "http://xn--pypal-4ve.com/login"}
    response = client.post("/api/v1/scan-url", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["threat_score"] >= 60.0
    factors_str = " ".join(data["risk_factors"]).lower()
    assert "punycode" in factors_str


def test_lru_cache_speed():
    """Validates repeated scans are served from memory in sub-5ms."""
    url = "https://www.wikipedia.org/wiki/Phishing"
    # First pass: Cache miss
    resp1 = client.post("/api/v1/scan-url", json={"url": url})
    assert resp1.status_code == 200

    # Second pass: Cache hit
    resp2 = client.post("/api/v1/scan-url", json={"url": url})
    assert resp2.status_code == 200
    data2 = resp2.json()
    assert data2["cached"] is True
    assert data2["latency_ms"] < 10.0


def test_scan_chat_legitimate():
    """Validates benign buyer conversation returns CLEAN status."""
    message = "Hi, is this still available? Can we meet at the library tomorrow at 3 PM? I will bring cash."
    response = client.post("/api/v1/scan-chat", json={"text": message, "platform": "messenger"})
    assert response.status_code == 200
    data = response.json()
    assert data["threat_level"] == "CLEAN"
    assert data["threat_score"] < 25.0
    assert len(data["detected_vectors"]) == 0


def test_scan_chat_otp_harvesting():
    """Validates 6-digit OTP exfiltration attempt is intercepted."""
    message = "I want to confirm you are real. I just sent a 6-digit Google Voice verification code to your phone. Send me the code now."
    response = client.post("/api/v1/scan-chat", json={"text": message, "platform": "telegram"})
    assert response.status_code == 200
    data = response.json()
    assert data["threat_score"] >= 65.0
    assert any(v["vector"] == "OTP_VERIFICATION_THEFT" for v in data["detected_vectors"])
    assert len(data["flagged_phrases"]) >= 1


def test_scan_chat_multi_vector_fraud():
    """Validates compound fraud (Zelle + Urgency + Courier) triggers CRITICAL alert."""
    message = (
        "My son will pick up the item tomorrow. I will pay in advance via Zelle right now. "
        "URGENT: Your account has been suspended, confirm within 15 minutes or funds are forfeited."
    )
    response = client.post("/api/v1/scan-chat", json={"text": message, "platform": "marketplace"})
    assert response.status_code == 200
    data = response.json()
    assert data["threat_level"] == "CRITICAL"
    assert data["threat_score"] >= 80.0
    assert data["vector_count"] >= 2


def test_scan_marketplace_listing():
    """Validates Marketplace scam pricing anomaly and courier story detection."""
    # Scam scenario: Brand new account, 75% under market price, courier story
    scam_payload = {
        "account_age_months": 1,
        "price": 250.0,
        "market_avg": 1000.0,
        "description": "Brand new MacBook Pro in box. My courier will bring the cash to you, shipping only.",
        "ships_only": True
    }
    response = client.post("/api/v1/scan-marketplace", json=scam_payload)
    assert response.status_code == 200
    data = response.json()
    assert data["threat_level"] in ["HIGH_RISK", "CRITICAL"]
    assert data["risk_score"] >= 60.0
    assert data["price_deviation_pct"] == 75.0
    assert len(data["anomalies"]) >= 2


def test_scan_url_malformed_does_not_crash():
    """Bad ports / broken IPv6 literals must not cause a 500."""
    for bad in ["http://a.com:99999/x", "http://[::1", "not a url"]:
        assert client.post("/api/v1/scan-url", json={"url": bad}).status_code == 200


def test_scan_url_brand_in_subdomain():
    """apple.com.verify-id.net is impersonation; google.co.uk / microsoftonline.com are not."""
    bad = client.post("/api/v1/scan-url", json={"url": "https://apple.com.verify-id.net/signin"}).json()
    assert bad["is_phishing"] is True
    for ok in ["https://www.google.co.uk/", "https://login.microsoftonline.com/common/oauth2/authorize"]:
        assert client.post("/api/v1/scan-url", json={"url": ok}).json()["is_phishing"] is False


def test_scan_chat_no_false_positives():
    """Everyday sentences with words like 'police', 'immediately' or a 6-digit order number stay CLEAN."""
    for msg in ["Let's meet immediately after work, my lawyer friend recommended this.",
                "Order #123456 has shipped, thanks!",
                "I'll call the police if you don't show up lol"]:
        assert client.post("/api/v1/scan-chat", json={"text": msg}).json()["threat_level"] == "CLEAN"


def test_empty_inputs_rejected():
    assert client.post("/api/v1/scan-url", json={"url": ""}).status_code == 422
    assert client.post("/api/v1/scan-chat", json={"text": ""}).status_code == 422


def test_model_metrics():
    """Validates model benchmarks returns all three models and GWO hyperparameters."""
    response = client.get("/api/v1/model-metrics")
    assert response.status_code == 200
    data = response.json()
    benchmarks = data["benchmarks"]
    assert "GWO_Random_Forest" in benchmarks
    assert "Linear_SVM" in benchmarks
    assert "Decision_Tree" in benchmarks
    assert benchmarks["GWO_Random_Forest"]["mcc"] >= 0.90
    assert "optimal_hyperparameters" in data
    assert "n_estimators" in data["optimal_hyperparameters"]


if __name__ == "__main__":
    pytest.main(["-v", __file__])
