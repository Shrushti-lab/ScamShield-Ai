"""
ScamShield AI - Dataset Generator
Produces 4,000+ balanced, labeled URL records and 1,000+ chat/Marketplace fraud transcripts.
"""

import csv
import json
import random
from pathlib import Path
from typing import List, Dict, Any

# Fix random seed for reproducible dataset generation
random.seed(42)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# -----------------------------------------------------------------------------
# URL Dataset Generator (4,000+ Balanced Records)
# -----------------------------------------------------------------------------
BENIGN_DOMAINS = [
    "google.com", "youtube.com", "facebook.com", "amazon.com", "wikipedia.org",
    "reddit.com", "twitter.com", "instagram.com", "linkedin.com", "github.com",
    "apple.com", "microsoft.com", "netflix.com", "yahoo.com", "zoom.us",
    "cloudflare.com", "bing.com", "office.com", "live.com", "spotify.com",
    "twitch.tv", "adobe.com", "cnn.com", "nytimes.com", "bbc.com",
    "chase.com", "bankofamerica.com", "wellsfargo.com", "paypal.com", "binance.com",
    "telegram.org", "whatsapp.com", "dropbox.com", "salesforce.com", "walmart.com",
    "ebay.com", "etsy.com", "target.com", "homedepot.com", "bestbuy.com",
    "craigslist.org", "imdb.com", "stackoverflow.com", "medium.com", "quora.com",
    "pinterest.com", "wordpress.org", "mozilla.org", "apache.org", "python.org"
]

BENIGN_PATHS = [
    "", "/about", "/contact", "/terms", "/privacy", "/help/article/1209",
    "/products/detail", "/search", "/docs/api/v2", "/explore", "/category/tech",
    "/user/profile", "/dashboard/overview", "/download/latest", "/blog/2026/03/update",
    "/checkout/cart", "/order/status", "/support/knowledge-base", "/news/headline"
]

BENIGN_QUERIES = [
    "", "?ref=header", "?utm_source=email&utm_medium=newsletter", "?page=2",
    "?q=cybersecurity+best+practices", "?sort=newest&limit=20", "?view=grid",
    "?lang=en-US", "?session_id=abc1234def", "?filter=active"
]

SUSPICIOUS_TLDS = [
    ".xyz", ".top", ".tk", ".buzz", ".club", ".work",
    ".click", ".gq", ".cf", ".ml", ".ga", ".fit", ".rest",
    ".monster", ".country", ".surf", ".stream", ".icu"
]

TARGET_BRANDS = [
    "paypal", "amazon", "facebook", "telegram", "apple",
    "binance", "chase", "netflix", "dhl", "coinbase", "wellsfargo"
]

PHISHING_KEYWORDS = [
    "verify", "wallet", "claim", "login", "bank", "secure",
    "airdrop", "confirm", "update", "signin", "account",
    "auth", "recover", "reward", "security-alert", "billing"
]

TYPO_HOMOGLYPHS = {
    "paypal": ["paypa1", "paypai", "paypa-l", "pay-pal", "peypal", "pypal"],
    "amazon": ["arnazon", "amaz0n", "amazn", "amzon-prime", "amazone-update"],
    "facebook": ["faceb00k", "face-book", "faecbook", "fb-security", "facbook"],
    "telegram": ["telegraam", "tele-gram", "telegrm", "t-gram", "telegram-vip"],
    "apple": ["app1e", "apple-id", "appl-support", "appie", "apple-login"],
    "binance": ["binan-ce", "binance-airdrop", "binanc", "binance-earn"],
    "chase": ["chase-online", "chase-bank-alert", "chas-e", "chasee"],
    "netflix": ["netf1ix", "net-flix", "netflix-billing", "netfllx"],
    "dhl": ["dhl-tracking", "dhl-express-fee", "dhl-courier", "dh1-parcel"]
}

PUNYCODE_DOMAINS = [
    "xn--pypal-4ve.com", "xn--amazn-rqa.xyz", "xn--appl-coa.top",
    "xn--facebok-8ya.club", "xn--tlegrm-dva.click", "xn--bnance-bva.work",
    "xn--chse-mqa.buzz", "xn--ntflix-cva.monster", "xn--dh-mja.icu"
]


def generate_random_dga_string(length: int = 10) -> str:
    chars = "abcdefghijklmnopqrstuvwxyz0123456789"
    return "".join(random.choice(chars) for _ in range(length))


def generate_url_dataset(num_samples: int = 4200) -> List[Dict[str, Any]]:
    """Generates a balanced dataset of 4,200+ legitimate and phishing URLs."""
    records: List[Dict[str, Any]] = []
    half = num_samples // 2

    # 1. Generate Benign URLs
    for _ in range(half):
        domain = random.choice(BENIGN_DOMAINS)
        sub = f"{random.choice(['www', 'api', 'app', 'm', 'cdn', 'auth'])}." if random.random() < 0.4 else ""
        scheme = "https://" if random.random() < 0.85 else "http://"
        path = random.choice(BENIGN_PATHS)
        query = random.choice(BENIGN_QUERIES) if path else ""
        url = f"{scheme}{sub}{domain}{path}{query}"
        records.append({"url": url, "label": 0})

    # 2. Generate Phishing / Malicious URLs
    for _ in range(half):
        scheme = "http://" if random.random() < 0.7 else "https://"
        pattern_type = random.choice(["typosquat", "brand_keyword", "punycode", "ip_address", "dga_subdomain", "double_slash"])

        if pattern_type == "typosquat":
            brand = random.choice(TARGET_BRANDS)
            typo = random.choice(TYPO_HOMOGLYPHS.get(brand, [brand + "-secure"]))
            tld = random.choice(SUSPICIOUS_TLDS) if random.random() < 0.75 else ".com"
            path = f"/{random.choice(PHISHING_KEYWORDS)}"
            url = f"{scheme}{typo}{tld}{path}?session={generate_random_dga_string(8)}"

        elif pattern_type == "brand_keyword":
            brand = random.choice(TARGET_BRANDS)
            kw = random.choice(PHISHING_KEYWORDS)
            tld = random.choice(SUSPICIOUS_TLDS)
            sep = random.choice(["-", "."])
            url = f"{scheme}{brand}{sep}{kw}{tld}/{random.choice(PHISHING_KEYWORDS)}.php?ref=urgent"

        elif pattern_type == "punycode":
            domain = random.choice(PUNYCODE_DOMAINS)
            url = f"{scheme}{domain}/login-verify?user={generate_random_dga_string(6)}"

        elif pattern_type == "ip_address":
            ip = f"{random.randint(11, 215)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
            port = f":{random.choice([8080, 8443, 8888, 3000, 4444])}" if random.random() < 0.5 else ""
            kw = random.choice(PHISHING_KEYWORDS)
            url = f"http://{ip}{port}/{kw}/signin.html"

        elif pattern_type == "dga_subdomain":
            dga = generate_random_dga_string(14)
            brand = random.choice(TARGET_BRANDS)
            tld = random.choice(SUSPICIOUS_TLDS)
            url = f"{scheme}{dga}.{brand}-verify{tld}/claim?airdrop=true"

        else: # double_slash redirect
            brand = random.choice(TARGET_BRANDS)
            tld = random.choice(SUSPICIOUS_TLDS)
            url = f"{scheme}{brand}-portal{tld}//auth.{brand}.com/recover"

        records.append({"url": url, "label": 1})

    random.shuffle(records)
    return records


# -----------------------------------------------------------------------------
# Chat / Marketplace Scam Transcripts (1,000+ Records)
# -----------------------------------------------------------------------------
ITEMS = ["iPhone 15 Pro", "PlayStation 5", "MacBook Air M2", "Rolex Submariner", "Gaming PC", "Leather Sofa", "Electric Scooter", "Canon EOS R6"]
COURIERS = ["FedEx", "DHL Express", "UPS Courier", "Postage Agent"]
RELATIVES = ["my son", "my daughter", "my husband", "my cousin", "my transport agent"]
PAYMENT_APPS = ["Zelle", "Venmo", "CashApp", "Wire Transfer", "Apple Gift Card", "Steam Gift Card"]

OTP_TEMPLATES = [
    "I want to make sure you are a real person before I come. I sent a 6-digit Google Voice verification code to your phone. Send me the code to prove you are legit.",
    "Hey! I sent a verification code to your number. Please share the code right away so I know you're not a scammer.",
    "To confirm your identity, read me the 6 digit PIN that was just texted to your mobile phone.",
    "I need to verify this listing. I just triggered a security code to your SMS, tell me the code to proceed.",
    "Can you give me the 6 digit code you just received? My business policy requires phone confirmation."
]

PAYMENT_TEMPLATES = [
    "I'll buy it today! I am currently out of town on business, but {relative} will pick it up tomorrow. Can I pay you in advance via {payment_app}?",
    "I want to take the {item}. Please send your email so I can send the money through {payment_app}. I will add an extra $50 for holding it.",
    "My courier will bring an envelope with cash, but first you need to pay a refundable ${amount} courier insurance fee via {payment_app}.",
    "I have made the payment on {payment_app}. You should receive an email stating your funds are pending until you send ${amount} to expand your account limit.",
    "I cannot pay cash because of company policy. Please buy a ${amount} {payment_app} and send pictures of the card front and back."
]

URGENCY_TEMPLATES = [
    "URGENT: Your account has been suspended due to suspicious activity. Click this link within 15 minutes or your funds will be permanently forfeited.",
    "FINAL NOTICE: A legal summons has been issued against your profile. Contact support immediately or local law enforcement will be dispatched.",
    "Security Alert: An unauthorized transaction of $940 was detected. Call our emergency fraud hotline within 30 minutes to cancel.",
    "Your wallet access has been restricted. You have 24 hours to verify your identity before account termination.",
    "Immediate action required! Your listing violates community standards. Verify ownership now or face permanent ban."
]

CRYPTO_TEMPLATES = [
    "Join our VIP signals channel! We guarantee 15% daily ROI with our automated AI bot. Recharge 200 USDT to activate your bonus.",
    "Earn $350/day from home just by liking YouTube videos and rating hotels! Deposit 50 USDT to unlock your task commission.",
    "EXCLUSIVE AIRDROP: Binance is giving away 5,000 USDT to the first 100 users! Connect your Web3 wallet and claim now.",
    "Our insider pump and dump group is launching a 100x moonshot coin today. Send 0.1 ETH to the presale contract to reserve tokens.",
    "Double your crypto in 24 hours! Send between 100 and 1,000 USDT to the VIP smart contract and receive 200% payout guaranteed."
]

LEGITIMATE_TEMPLATES = [
    "Hi, is the {item} still available? Can we meet at the Starbucks on Main Street tomorrow at 2 PM? I'll bring cash.",
    "Hello! What is the condition of the {item}? Are there any scratches or dents on the screen?",
    "Thanks for the quick reply. Would you be willing to take $20 off if I pick it up this evening?",
    "Hey there, does it come with the original box, receipt, and charging cable?",
    "Sounds great. I finish work around 5:30 PM. What neighborhood are you located in for local pickup?",
    "Just wanted to confirm our meetup today at 3 PM at the police station safe exchange zone."
]


def generate_chat_dataset(num_samples: int = 1200) -> List[Dict[str, Any]]:
    """Generates 1,200+ labeled chat/Marketplace transcripts."""
    transcripts: List[Dict[str, Any]] = []

    # Categories to generate in equal balance
    categories = [
        ("OTP_THEFT", OTP_TEMPLATES, 1),
        ("PAYMENT_PIVOT", PAYMENT_TEMPLATES, 1),
        ("URGENCY_COERCION", URGENCY_TEMPLATES, 1),
        ("CRYPTO_TASK_FRAUD", CRYPTO_TEMPLATES, 1),
        ("LEGITIMATE", LEGITIMATE_TEMPLATES, 0)
    ]

    samples_per_cat = num_samples // len(categories)

    for cat_name, template_list, is_fraud in categories:
        for _ in range(samples_per_cat):
            tmpl = random.choice(template_list)
            text = tmpl.format(
                item=random.choice(ITEMS),
                relative=random.choice(RELATIVES),
                payment_app=random.choice(PAYMENT_APPS),
                amount=random.choice([30, 50, 100, 200, 500])
            )
            # Add minor natural variations
            if random.random() < 0.2:
                text = text.upper()
            elif random.random() < 0.2:
                text += f" Contact me quickly at test{random.randint(10,99)}@gmail.com"

            transcripts.append({
                "text": text,
                "category": cat_name,
                "is_fraud": is_fraud,
                "platform": random.choice(["telegram", "facebook_marketplace", "messenger"])
            })

    random.shuffle(transcripts)
    return transcripts


def main():
    print("[ScamShield AI] Generating synthetic URL security dataset...")
    url_data = generate_url_dataset(num_samples=4200)
    url_csv_path = DATA_DIR / "url_dataset.csv"

    with open(url_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["url", "label"])
        writer.writeheader()
        writer.writerows(url_data)

    print(f"[ScamShield AI] Saved {len(url_data)} URL samples to {url_csv_path}")

    print("[ScamShield AI] Generating synthetic Chat & Marketplace transcripts...")
    chat_data = generate_chat_dataset(num_samples=1200)
    chat_json_path = DATA_DIR / "chat_dataset.json"

    with open(chat_json_path, "w", encoding="utf-8") as f:
        json.dump(chat_data, f, indent=2)

    print(f"[ScamShield AI] Saved {len(chat_data)} chat transcripts to {chat_json_path}")


if __name__ == "__main__":
    main()
