/**
 * ScamShield AI - Background Service Worker (Manifest V3)
 * Telemetry proxy, tab inspection, badge status updater, and API gateway.
 * Implements persistent session storage to survive service-worker idle terminations.
 */

const BACKEND_BASE_URL = "http://127.0.0.1:8000";

// Fallback to local storage with prefix if session storage is unavailable
const sessionStore = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.session)
  ? chrome.storage.session
  : chrome.storage.local;

/**
 * Persists tab telemetry in session storage and local cache.
 */
async function setTabTelemetry(tabId, telemetry) {
  if (!tabId || !telemetry) return;
  const key = `tab_telemetry_${tabId}`;
  try {
    await sessionStore.set({ [key]: telemetry });
    await chrome.storage.local.set({
      "last_active_scan": telemetry,
      [`tab_cache_${tabId}`]: telemetry
    });
  } catch (err) {
    console.warn("[ScamShield BG] Failed to persist tab telemetry:", err);
  }
}

/**
 * Retrieves tab telemetry across service-worker lifecycle restarts.
 */
async function getTabTelemetry(tabId, allowGlobalFallback = true) {
  if (tabId) {
    const key = `tab_telemetry_${tabId}`;
    try {
      const res = await sessionStore.get(key);
      if (res && res[key]) return res[key];

      const localRes = await chrome.storage.local.get(`tab_cache_${tabId}`);
      if (localRes && localRes[`tab_cache_${tabId}`]) return localRes[`tab_cache_${tabId}`];
    } catch (err) {
      console.warn("[ScamShield BG] Error reading tab telemetry:", err);
    }
  }

  if (!allowGlobalFallback) return null;

  try {
    const fallback = await chrome.storage.local.get("last_active_scan");
    return fallback.last_active_scan || null;
  } catch {
    return null;
  }
}

/**
 * Removes tab telemetry on tab close.
 */
async function removeTabTelemetry(tabId) {
  if (!tabId) return;
  const key = `tab_telemetry_${tabId}`;
  try {
    await sessionStore.remove(key);
    await chrome.storage.local.remove(`tab_cache_${tabId}`);
  } catch (err) {
    console.warn("[ScamShield BG] Failed to remove tab telemetry:", err);
  }
}

/**
 * Updates extension action badge based on threat score.
 */
function updateBadge(tabId, threatScore, isPhishing) {
  let badgeText = "OK";
  let badgeColor = "#10b981"; // Radar green

  if (threatScore >= 75 || isPhishing) {
    badgeText = `!${Math.round(threatScore)}`;
    badgeColor = "#ef4444"; // Alert crimson
  } else if (threatScore >= 40) {
    badgeText = `!${Math.round(threatScore)}`;
    badgeColor = "#f59e0b"; // Warning amber
  } else {
    badgeText = "SAFE";
    badgeColor = "#10b981";
  }

  try {
    const setPromise = chrome.action.setBadgeText({ tabId, text: badgeText });
    if (setPromise && typeof setPromise.catch === "function") {
      setPromise.catch(() => {});
    }
    const colorPromise = chrome.action.setBadgeBackgroundColor({ tabId, color: badgeColor });
    if (colorPromise && typeof colorPromise.catch === "function") {
      colorPromise.catch(() => {});
    }
  } catch {
    // Ignore synchronous tab closed exceptions
  }
}

/**
 * Performs URL threat scan against ScamShield AI backend with heuristic fallback.
 */
async function scanUrlWithBackend(url) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const response = await fetch(`${BACKEND_BASE_URL}/api/v1/scan-url`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (response.ok) {
      return await response.json();
    }
  } catch (err) {
    console.warn("[ScamShield BG] Backend unreachable or timeout. Using client-side heuristic:", err);
  }

  // Client-side heuristic fallback when backend is starting or offline
  return clientFallbackUrlScan(url);
}

/**
 * Robust client-side fallback heuristic when backend is offline.
 */
function clientFallbackUrlScan(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return {
      url,
      is_phishing: false,
      threat_score: 10,
      confidence: 0.5,
      entropy: 2.5,
      risk_factors: ["URL format unverified"],
      advisory: "Proceed with standard caution.",
      cached: false,
      latency_ms: 1
    };
  }

  const host = parsed.hostname.toLowerCase();
  let score = 5;
  const factors = [];

  const suspiciousTlds = [".xyz", ".top", ".tk", ".buzz", ".club", ".work", ".click", ".icu", ".monster"];
  if (suspiciousTlds.some(tld => host.endsWith(tld))) {
    score += 45;
    factors.push("High-risk TLD detected.");
  }

  const brandSpoofs = ["paypal", "amazon", "chase", "apple", "binance", "telegram", "facebook"];
  if (brandSpoofs.some(brand => host.includes(brand) && !host.endsWith(`${brand}.com`))) {
    score += 40;
    factors.push("Brand keyword in non-official domain.");
  }

  if (host.includes("xn--")) {
    score += 40;
    factors.push("Punycode homoglyph detected.");
  }

  if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(host)) {
    score += 40;
    factors.push("Raw IP address used as host.");
  }

  const threat_score = Math.min(score, 99);
  return {
    url,
    is_phishing: threat_score >= 60,
    threat_score,
    confidence: 0.8,
    entropy: 3.2,
    risk_factors: factors,
    advisory: threat_score >= 60 ? "CRITICAL: Potential deceptive website." : "SECURE: No overt anomalies detected.",
    cached: false,
    latency_ms: 2
  };
}

// -----------------------------------------------------------------------------
// Tab URL Monitoring Listener
// -----------------------------------------------------------------------------
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && tab.url.startsWith("http")) {
    scanUrlWithBackend(tab.url).then(async (telemetry) => {
      await setTabTelemetry(tabId, telemetry);
      updateBadge(tabId, telemetry.threat_score, telemetry.is_phishing);

      // Broadcast threat status to the content script in this tab
      chrome.tabs.sendMessage(tabId, {
        type: "TAB_THREAT_UPDATED",
        data: telemetry
      }).catch(() => {});
    });
  }
});

// Clean up memory on tab close
chrome.tabs.onRemoved.addListener(async (tabId) => {
  await removeTabTelemetry(tabId);
});

// Restore active tab badge upon service worker wake-up
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs && tabs[0]) {
    getTabTelemetry(tabs[0].id).then(telemetry => {
      if (telemetry) {
        updateBadge(tabs[0].id, telemetry.threat_score, telemetry.is_phishing);
      }
    });
  }
});

// -----------------------------------------------------------------------------
// Message Gateway for Content Scripts & Popup
// -----------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const { type, payload } = request;

  if (type === "SCAN_URL") {
    scanUrlWithBackend(payload.url).then(sendResponse);
    return true; // Keep message channel open for async response
  }

  if (type === "SCAN_CHAT") {
    fetch(`${BACKEND_BASE_URL}/api/v1/scan-chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(res => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.json(); })
      .then(sendResponse)
      .catch(err => {
        console.warn("[ScamShield BG] Chat scan error:", err);
        sendResponse({
          offline: true,
          threat_score: 0,
          threat_level: "UNKNOWN",
          detected_vectors: [],
          flagged_phrases: [],
          advisory: "Backend offline. Scan skipped (NOT verified safe)."
        });
      });
    return true;
  }

  if (type === "SCAN_MARKETPLACE") {
    fetch(`${BACKEND_BASE_URL}/api/v1/scan-marketplace`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(res => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.json(); })
      .then(sendResponse)
      .catch(err => {
        console.warn("[ScamShield BG] Marketplace scan error:", err);
        sendResponse({
          offline: true,
          risk_score: 0,
          threat_level: "UNKNOWN",
          anomalies: [],
          recommendation: "Backend offline. Scan skipped (NOT verified safe)."
        });
      });
    return true;
  }

  if (type === "GET_TAB_TELEMETRY") {
    const tabId = payload?.tabId || sender.tab?.id;
    // A content script must only ever see its own tab's result, never another tab's
    getTabTelemetry(tabId, !sender.tab).then(sendResponse);
    return true;
  }

  if (type === "GET_BENCHMARKS") {
    fetch(`${BACKEND_BASE_URL}/api/v1/model-metrics`)
      .then(res => res.json())
      .then(sendResponse)
      .catch(err => {
        console.warn("[ScamShield BG] Failed to fetch benchmarks:", err);
        sendResponse(null);
      });
    return true;
  }

  return false;
});
