/**
 * ScamShield AI - Popup Controller & Tactical Telemetry HUD
 * Handles tab telemetry, SVG threat gauge animation, manual scanner, and benchmark viewer.
 */

const BACKEND_URL = "http://127.0.0.1:8000";
const CIRCUMFERENCE = 2 * Math.PI * 50; // ~314.159

// Escape untrusted text before it is placed into innerHTML
function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

document.addEventListener("DOMContentLoaded", () => {
  initializeTabs();
  checkBackendHealth();
  loadActiveTabTelemetry();
  setupManualScanner();
  loadModelBenchmarks();
});

// -----------------------------------------------------------------------------
// Tab Switching System
// -----------------------------------------------------------------------------
function initializeTabs() {
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabSections = {
    target: document.getElementById("tabTarget"),
    scanner: document.getElementById("tabScanner"),
    benchmarks: document.getElementById("tabBenchmarks")
  };

  tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      tabButtons.forEach(b => b.classList.remove("active"));
      Object.values(tabSections).forEach(s => s.classList.remove("active"));

      btn.classList.add("active");
      const targetId = btn.getAttribute("data-tab");
      if (tabSections[targetId]) {
        tabSections[targetId].classList.add("active");
      }
    });
  });
}

// -----------------------------------------------------------------------------
// Backend Status Ping
// -----------------------------------------------------------------------------
async function checkBackendHealth() {
  const badge = document.getElementById("backendStatusBadge");
  const text = document.getElementById("backendStatusText");
  try {
    const res = await fetch(`${BACKEND_URL}/api/v1/health`, { method: "GET" });
    if (res.ok) {
      const data = await res.json();
      text.textContent = data.model_loaded ? "ML MODEL ACTIVE" : "BACKEND UP (FALLBACK MODEL)";
      badge.style.borderColor = "rgba(16, 185, 129, 0.4)";
      badge.style.color = "#10b981";
      return;
    }
  } catch {
    // Offline fallback
  }
  text.textContent = "BACKEND OFFLINE (BASIC CHECKS)";
  badge.style.borderColor = "rgba(245, 158, 11, 0.4)";
  badge.style.color = "#f59e0b";
}

// -----------------------------------------------------------------------------
// Active Tab Inspection & Gauge Animation
// -----------------------------------------------------------------------------
async function loadActiveTabTelemetry() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || tabs.length === 0) return;
    const activeTab = tabs[0];
    const url = activeTab.url || "";

    const urlDisplay = document.getElementById("targetUrlText");
    urlDisplay.textContent = url.replace(/^https?:\/\//, "");

    // Request telemetry from background worker
    chrome.runtime.sendMessage(
      { type: "GET_TAB_TELEMETRY", payload: { tabId: activeTab.id } },
      (telemetry) => {
        if (telemetry) {
          renderTelemetryHUD(telemetry);
        } else if (url.startsWith("http")) {
          // Direct scan fallback
          chrome.runtime.sendMessage(
            { type: "SCAN_URL", payload: { url } },
            (freshScan) => {
              if (freshScan) renderTelemetryHUD(freshScan);
            }
          );
        } else {
          renderInternalPageHUD(url);
        }
      }
    );
  });
}

function updateRadialGauge(score) {
  const circle = document.getElementById("threatGaugeCircle");
  const scoreText = document.getElementById("threatScoreValue");
  if (!circle || !scoreText) return;

  const boundedScore = Math.max(0, Math.min(100, score));
  const offset = CIRCUMFERENCE - (boundedScore / 100) * CIRCUMFERENCE;

  circle.style.strokeDashoffset = offset;
  scoreText.textContent = Math.round(boundedScore);

  if (boundedScore >= 75) {
    circle.style.stroke = "#ef4444";
  } else if (boundedScore >= 40) {
    circle.style.stroke = "#f59e0b";
  } else {
    circle.style.stroke = "#10b981";
  }
}

function renderTelemetryHUD(data) {
  const score = data.threat_score || 0;
  updateRadialGauge(score);

  const levelTag = document.getElementById("threatLevelTag");
  levelTag.className = "threat-level-tag";
  if (score >= 75 || data.is_phishing) {
    levelTag.textContent = "CRITICAL THREAT";
    levelTag.classList.add("critical");
  } else if (score >= 40) {
    levelTag.textContent = "SUSPICIOUS / ELEVATED";
    levelTag.classList.add("warning");
  } else {
    levelTag.textContent = "SECURE / VERIFIED";
    levelTag.classList.add("clean");
  }

  // Telemetry indicators
  const entropy = Number(data.entropy) || 0;
  document.getElementById("valEntropy").textContent = entropy.toFixed(2);
  const entropyPct = Math.min((entropy / 5.0) * 100, 100);
  document.getElementById("barEntropy").style.width = `${entropyPct}%`;

  const confPct = Math.round((Number(data.confidence) || 0) * 100);
  document.getElementById("valConfidence").textContent = `${confPct}%`;
  document.getElementById("barConfidence").style.width = `${confPct}%`;

  const latency = data.latency_ms ? `${data.latency_ms}ms` : "n/a";
  document.getElementById("valLatency").textContent = latency;

  // Advisory & factors
  const advisoryEl = document.getElementById("advisoryText");
  advisoryEl.textContent = data.advisory || "Session monitored in real-time.";

  const factorsList = document.getElementById("riskFactorsList");
  factorsList.innerHTML = "";
  if (data.risk_factors && data.risk_factors.length > 0) {
    data.risk_factors.forEach(factor => {
      const li = document.createElement("li");
      li.textContent = factor;
      factorsList.appendChild(li);
    });
  }
}

function renderInternalPageHUD(url) {
  updateRadialGauge(0);
  const levelTag = document.getElementById("threatLevelTag");
  levelTag.className = "threat-level-tag clean";
  levelTag.textContent = "LOCAL BROWSER SURFACE";

  document.getElementById("valEntropy").textContent = "n/a";
  document.getElementById("barEntropy").style.width = "0%";
  document.getElementById("valConfidence").textContent = "n/a";
  document.getElementById("barConfidence").style.width = "0%";
  document.getElementById("valLatency").textContent = "n/a";
  document.getElementById("advisoryText").textContent = "System tab / browser internal page.";
  document.getElementById("riskFactorsList").innerHTML = "";
}

// -----------------------------------------------------------------------------
// Manual Threat Scanner
// -----------------------------------------------------------------------------
function setupManualScanner() {
  const input = document.getElementById("manualInput");
  const btnUrl = document.getElementById("btnScanUrl");
  const btnChat = document.getElementById("btnScanChat");
  const resultBox = document.getElementById("scannerResult");
  const resultScore = document.getElementById("scanResultScore");
  const resultBody = document.getElementById("scanResultBody");

  function showError(message) {
    resultBox.classList.remove("hidden");
    resultScore.textContent = "N/A";
    resultScore.style.color = "#9ca3af";
    resultBody.innerHTML = `<div style="font-size: 11px; color: #fca5a5;">${esc(message)}</div>`;
  }

  async function postJson(path, body) {
    const res = await fetch(`${BACKEND_URL}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error(`Backend returned HTTP ${res.status}`);
    return res.json();
  }

  btnUrl.addEventListener("click", async () => {
    const text = input.value.trim();
    if (!text) return;
    btnUrl.disabled = true;
    btnUrl.textContent = "SCANNING...";
    try {
      renderScanResult(await postJson("/api/v1/scan-url", { url: text }), "url");
    } catch {
      // Backend unreachable: use the extension's built-in basic checks
      chrome.runtime.sendMessage({ type: "SCAN_URL", payload: { url: text } }, (data) => {
        if (chrome.runtime.lastError || !data) showError("Could not scan this URL.");
        else renderScanResult(data, "url");
      });
    } finally {
      btnUrl.disabled = false;
      btnUrl.textContent = "SCAN AS URL";
    }
  });

  btnChat.addEventListener("click", async () => {
    const text = input.value.trim();
    if (!text) return;
    btnChat.disabled = true;
    btnChat.textContent = "ANALYZING...";
    try {
      renderScanResult(await postJson("/api/v1/scan-chat", { text, platform: "generic" }), "chat");
    } catch {
      showError(`Backend API unreachable at ${BACKEND_URL}. Start the server and try again.`);
    } finally {
      btnChat.disabled = false;
      btnChat.textContent = "SCAN AS CHAT";
    }
  });

  function renderScanResult(data, type) {
    resultBox.classList.remove("hidden");
    const score = Math.round(data.threat_score || 0);
    resultScore.textContent = `${score}% RISK`;

    if (score >= 75) {
      resultScore.style.color = "#ef4444";
    } else if (score >= 40) {
      resultScore.style.color = "#f59e0b";
    } else {
      resultScore.style.color = "#10b981";
    }

    if (type === "url") {
      const factors = (data.risk_factors || []).map(f => `<li>⚠️ ${esc(f)}</li>`).join("");
      resultBody.innerHTML = `
        <div style="font-size: 11px; margin-bottom: 6px; color: #d1d5db;">${esc(data.advisory)}</div>
        <div style="font-size: 10px; color: #9ca3af; margin-bottom: 4px;">Shannon Entropy: <strong>${esc(data.entropy)}</strong> | Confidence: <strong>${Math.round((data.confidence||0)*100)}%</strong></div>
        ${factors ? `<ul style="padding-left: 16px; font-size: 11px; color: #f87171;">${factors}</ul>` : ""}
      `;
    } else {
      const vectors = (data.detected_vectors || [])
        .map(v => `<div style="font-size: 10px; color: #93c5fd; margin-bottom: 3px;">• <strong>${esc(v.vector)}</strong> (${esc(v.score)}%): ${esc(v.description)}</div>`)
        .join("");
      const tokens = (data.flagged_phrases || []).map(p => `<code style="background:#1f202e;color:#fca5a5;padding:1px 3px;border-radius:2px;font-size:10px;">"${esc(p)}"</code>`).join(" ");

      resultBody.innerHTML = `
        <div style="font-size: 11px; margin-bottom: 6px; color: #d1d5db;">${esc(data.advisory)}</div>
        ${vectors ? `<div style="margin: 6px 0;">${vectors}</div>` : ""}
        ${tokens ? `<div style="font-size: 10px; color:#9ca3af; margin-top:4px;">Flagged Tokens: ${tokens}</div>` : ""}
      `;
    }
  }
}

// -----------------------------------------------------------------------------
// AI Model Benchmarks Viewer
// -----------------------------------------------------------------------------
async function loadModelBenchmarks() {
  try {
    const res = await fetch(`${BACKEND_URL}/api/v1/model-metrics`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    const tbody = document.getElementById("benchmarkTbody");
    tbody.innerHTML = "";

    const bm = data.benchmarks || {};
    const order = ["GWO_Random_Forest", "Linear_SVM", "Decision_Tree"];

    order.forEach(name => {
      const m = bm[name];
      if (!m) return;
      const tr = document.createElement("tr");
      if (name.includes("GWO")) tr.className = "highlight-row";

      const displayName = name.replace(/_/g, " ");
      tr.innerHTML = `
        <td>${esc(displayName)}</td>
        <td>${m.accuracy.toFixed(3)}</td>
        <td>${m.precision.toFixed(3)}</td>
        <td>${m.recall.toFixed(3)}</td>
        <td>${m.f1_score.toFixed(3)}</td>
        <td>${m.mcc.toFixed(3)}</td>
      `;
      tbody.appendChild(tr);
    });

    const opt = data.optimal_hyperparameters || {};
    if (opt.n_estimators) document.getElementById("gwoTrees").textContent = opt.n_estimators;
    if (opt.max_depth) document.getElementById("gwoDepth").textContent = opt.max_depth;
    if (opt.min_samples_split) document.getElementById("gwoSplit").textContent = opt.min_samples_split;
    if (opt.mcc_fitness) document.getElementById("gwoMcc").textContent = `${opt.mcc_fitness.toFixed(4)} MCC`;
  } catch (err) {
    console.warn("[ScamShield Popup] Failed to load benchmark telemetry:", err);
    const tbody = document.getElementById("benchmarkTbody");
    if (tbody) tbody.innerHTML = '<tr><td colspan="6">Benchmarks unavailable (backend offline).</td></tr>';
  }
}
