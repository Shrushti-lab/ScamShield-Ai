/**
 * ScamShield AI - In-Browser Threat Interceptor & Security Sandbox
 * Monitors Telegram Web (A & K), Facebook Messenger & Marketplace feeds.
 * Implements Closed Shadow DOM security isolation and Credit Card Harvester Trap.
 */

(() => {
  // Prevent duplicate script execution
  if (window.__SCAMSHIELD_INITIALIZED__) return;
  window.__SCAMSHIELD_INITIALIZED__ = true;

  console.log("%c[ScamShield AI]%c Active Defense Grid Initialized.", "color: #10b981; font-weight: bold;", "color: #f3f4f6;");

  // Escape untrusted text (page content / API strings) before it is placed into innerHTML
  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  let currentTabTelemetry = null;
  let creditCardTrapBypassed = false;

  // ---------------------------------------------------------------------------
  // Web Audio Tactical Alert Sound Generator
  // ---------------------------------------------------------------------------
  function playTacticalAlarmSound() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(880, ctx.currentTime); // High A5
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.18);

      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // Audio context may be restricted by autoplay policy until user gesture
    }
  }

  // ---------------------------------------------------------------------------
  // Closed Shadow DOM Injected Pill Component
  // ---------------------------------------------------------------------------
  function injectTacticalPill(targetNode, scanResult) {
    if (!targetNode || targetNode.hasAttribute("data-scamshield-badged")) return;
    targetNode.setAttribute("data-scamshield-badged", "true");

    const host = document.createElement("div");
    host.className = "scamshield-injected-badge-host";
    
    // Closed Shadow DOM to guarantee zero style collision with host site
    const shadow = host.attachShadow({ mode: "closed" });

    const isCritical = scanResult.threat_score >= 75 || scanResult.threat_level === "CRITICAL";
    const isWarning = scanResult.threat_score >= 40 || scanResult.threat_level === "HIGH_RISK";
    const accentColor = isCritical ? "#ef4444" : (isWarning ? "#f59e0b" : "#10b981");
    const glowColor = isCritical ? "rgba(239, 68, 68, 0.35)" : (isWarning ? "rgba(245, 158, 11, 0.3)" : "rgba(16, 185, 129, 0.25)");
    const badgeLabel = isCritical ? "THREAT DETECTED" : (isWarning ? "RISK WARNING" : "VERIFIED SAFE");

    const vectorsHtml = (scanResult.detected_vectors || [])
      .map(v => `<span class="vector-tag">${esc(String(v.vector).replace(/_/g, " "))}: ${esc(v.score)}%</span>`)
      .join("");

    const indicatorsHtml = (scanResult.flagged_phrases || [])
      .map(p => `<code>"${esc(p)}"</code>`)
      .join(", ");

    shadow.innerHTML = `
      <style>
        :host {
          display: block;
          all: initial;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "JetBrains Mono", monospace;
          margin: 6px 0;
        }
        .shield-pill {
          background: #0d0e15;
          border: 1px solid ${accentColor};
          box-shadow: 0 2px 10px ${glowColor};
          border-radius: 6px;
          padding: 8px 12px;
          color: #f3f4f6;
          font-size: 12px;
          display: flex;
          flex-direction: column;
          gap: 6px;
          animation: fadeIn 0.2s ease-out;
        }
        .pill-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-weight: 700;
          letter-spacing: 0.5px;
        }
        .pill-title {
          display: flex;
          align-items: center;
          gap: 6px;
          color: ${accentColor};
          text-transform: uppercase;
        }
        .score-chip {
          background: ${accentColor};
          color: #000;
          font-weight: 800;
          font-size: 11px;
          padding: 2px 6px;
          border-radius: 4px;
        }
        .pill-vectors {
          display: flex;
          flex-wrap: wrap;
          gap: 4px;
        }
        .vector-tag {
          background: #181926;
          border: 1px solid #2e3048;
          color: #93c5fd;
          font-size: 10px;
          padding: 2px 5px;
          border-radius: 3px;
          text-transform: uppercase;
        }
        .pill-advisory {
          color: #e5e7eb;
          font-size: 11px;
          line-height: 1.4;
          background: rgba(255, 255, 255, 0.04);
          padding: 6px 8px;
          border-radius: 4px;
          border-left: 3px solid ${accentColor};
        }
        .pill-evidence {
          color: #9ca3af;
          font-size: 10px;
        }
        code {
          color: #fca5a5;
          background: #1f202e;
          padding: 1px 4px;
          border-radius: 3px;
          font-family: monospace;
        }
        .expand-toggle {
          background: none;
          border: none;
          color: #60a5fa;
          font-size: 10px;
          cursor: pointer;
          padding: 0;
          text-align: left;
          text-decoration: underline;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-4px); }
          to { opacity: 1; transform: translateY(0); }
        }
      </style>
      <div class="shield-pill">
        <div class="pill-header">
          <div class="pill-title">
            <span>🛡️ SCAMSHIELD AI:</span>
            <span>${esc(badgeLabel)}</span>
          </div>
          <div class="score-chip">${Math.round(scanResult.threat_score)}% RISK</div>
        </div>
        ${vectorsHtml ? `<div class="pill-vectors">${vectorsHtml}</div>` : ""}
        <div class="pill-advisory">
          ${esc(scanResult.advisory || scanResult.recommendation)}
        </div>
        ${indicatorsHtml ? `<div class="pill-evidence">Trigger Tokens: ${indicatorsHtml}</div>` : ""}
      </div>
    `;

    // Insert after target element
    targetNode.insertAdjacentElement("afterend", host);
  }

  // ---------------------------------------------------------------------------
  // Credit Card Harvester Trap Modal (Closed Shadow DOM)
  // ---------------------------------------------------------------------------
  function triggerCreditCardTrap(inputElement) {
    if (creditCardTrapBypassed) return;
    if (document.getElementById("scamshield-cc-trap-host")) return;

    // Check domain whitelist
    const host = window.location.hostname.toLowerCase();
    const trustedPaymentGateways = [
      "paypal.com", "stripe.com", "square.com", "amazon.com", "apple.com",
      "google.com", "shopify.com", "authorize.net", "klarna.com", "store.steampowered.com"
    ];
    const isTrusted = trustedPaymentGateways.some(gw => host === gw || host.endsWith("." + gw));

    // If trusted domain and low threat score, allow normal flow
    if (isTrusted && (!currentTabTelemetry || currentTabTelemetry.threat_score < 40)) {
      return;
    }

    playTacticalAlarmSound();

    const hostDiv = document.createElement("div");
    hostDiv.id = "scamshield-cc-trap-host";
    hostDiv.className = "scamshield-modal-host";
    const shadow = hostDiv.attachShadow({ mode: "closed" });

    const riskScore = currentTabTelemetry ? Math.round(currentTabTelemetry.threat_score) : 78;
    const entropy = currentTabTelemetry ? currentTabTelemetry.entropy : "High";
    const reasons = currentTabTelemetry?.risk_factors?.length
      ? currentTabTelemetry.risk_factors.map(r => `<li>⚠️ ${esc(r)}</li>`).join("")
      : "<li>⚠️ Unverified e-commerce checkout page or unauthenticated payment collector.</li><li>⚠️ High probability of credit card skimming or automated credential interception.</li>";

    shadow.innerHTML = `
      <style>
        :host {
          all: initial;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          background: rgba(9, 9, 11, 0.88);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 2147483647;
          animation: modalFadeIn 0.25s ease-out;
        }
        .modal-container {
          background: #0e0f17;
          border: 2px solid #ef4444;
          box-shadow: 0 0 35px rgba(239, 68, 68, 0.45);
          border-radius: 12px;
          width: 90%;
          max-width: 540px;
          padding: 28px;
          color: #f3f4f6;
          box-sizing: border-box;
          position: relative;
        }
        .banner {
          display: flex;
          align-items: center;
          gap: 12px;
          border-bottom: 1px solid #27273a;
          padding-bottom: 16px;
          margin-bottom: 18px;
        }
        .alert-icon {
          font-size: 32px;
          line-height: 1;
        }
        .title-group h2 {
          margin: 0;
          font-size: 18px;
          color: #ef4444;
          font-weight: 800;
          letter-spacing: 0.5px;
          text-transform: uppercase;
        }
        .title-group p {
          margin: 4px 0 0 0;
          font-size: 12px;
          color: #9ca3af;
        }
        .threat-metrics {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          background: #141522;
          padding: 12px;
          border-radius: 8px;
          border: 1px solid #25263a;
          margin-bottom: 16px;
        }
        .metric-cell {
          font-size: 11px;
          color: #9ca3af;
        }
        .metric-cell span {
          display: block;
          font-size: 16px;
          font-weight: 700;
          color: #f3f4f6;
          margin-top: 2px;
        }
        .metric-cell.danger span {
          color: #ef4444;
        }
        .reason-list {
          margin: 0 0 20px 0;
          padding-left: 20px;
          font-size: 12px;
          color: #d1d5db;
          line-height: 1.6;
        }
        .actions {
          display: flex;
          gap: 12px;
          justify-content: flex-end;
        }
        button {
          padding: 10px 18px;
          border-radius: 6px;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .btn-abort {
          background: #ef4444;
          border: 1px solid #ef4444;
          color: #ffffff;
          box-shadow: 0 0 12px rgba(239, 68, 68, 0.4);
        }
        .btn-abort:hover {
          background: #dc2626;
        }
        .btn-override {
          background: transparent;
          border: 1px solid #374151;
          color: #9ca3af;
        }
        .btn-override:hover {
          border-color: #6b7280;
          color: #f3f4f6;
        }
        @keyframes modalFadeIn {
          from { opacity: 0; transform: scale(0.96); }
          to { opacity: 1; transform: scale(1); }
        }
      </style>
      <div class="modal-overlay">
        <div class="modal-container">
          <div class="banner">
            <div class="alert-icon">🛑</div>
            <div class="title-group">
              <h2>Card Harvester Trap Triggered</h2>
              <p>Host: <strong>${esc(host)}</strong></p>
            </div>
          </div>
          <div class="threat-metrics">
            <div class="metric-cell danger">
              Target Threat Risk
              <span>${riskScore}% CRITICAL</span>
            </div>
            <div class="metric-cell">
              Shannon Entropy
              <span>${esc(entropy)}</span>
            </div>
          </div>
          <ul class="reason-list">
            ${reasons}
          </ul>
          <div class="actions">
            <button id="btn-override" class="btn-override">Bypass Warning (Proceed)</button>
            <button id="btn-abort" class="btn-abort">Abort & Clear Form</button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(hostDiv);

    shadow.getElementById("btn-abort").addEventListener("click", () => {
      if (inputElement) {
        inputElement.value = "";
        inputElement.blur();
      }
      // Clear all credit card inputs in active form
      document.querySelectorAll('input[autocomplete*="cc-"], input[name*="card" i], input[name*="cvv" i], input[id*="credit" i]')
        .forEach(el => el.value = "");
      hostDiv.remove();
    });

    shadow.getElementById("btn-override").addEventListener("click", () => {
      creditCardTrapBypassed = true;
      hostDiv.remove();
      if (inputElement) inputElement.focus();
    });
  }

  // ---------------------------------------------------------------------------
  // Input Monitor for Payment Forms (Credit Card Skimmer Trap)
  // ---------------------------------------------------------------------------
  function attachCreditCardTrapListeners() {
    const ccSelectors = [
      'input[autocomplete*="cc-"]',
      'input[name*="card" i]:not([type="hidden"])',
      'input[name*="cc_number" i]',
      'input[name*="cvv" i]',
      'input[id*="credit" i]',
      'input[id*="cardNumber" i]'
    ];

    document.querySelectorAll(ccSelectors.join(", ")).forEach(input => {
      if (input.hasAttribute("data-scamshield-trap-attached")) return;
      input.setAttribute("data-scamshield-trap-attached", "true");

      input.addEventListener("focus", () => triggerCreditCardTrap(input));
      input.addEventListener("input", () => triggerCreditCardTrap(input));
    });
  }

  // ---------------------------------------------------------------------------
  // Telegram Web Parser (Web A & Web K Support)
  // ---------------------------------------------------------------------------
  function scanTelegramMessages() {
    const hostname = window.location.hostname;
    const isSandbox = Boolean(document.querySelector("[data-scamshield-sandbox]") || window.location.href.includes("sandbox"));
    if (!hostname.includes("telegram.org") && !isSandbox) return;

    // Resilient Dual-Selector Engine:
    // Web A: .message-content, .bubble, .Message, .text-content
    // Web K: .message-container, .peer-title, .bubble-content
    const messageElements = document.querySelectorAll(`
      .message-content:not([data-scamshield-scanned="true"]),
      .bubble:not([data-scamshield-scanned="true"]),
      .message:not([data-scamshield-scanned="true"]),
      .bubble-content:not([data-scamshield-scanned="true"]),
      .text-content:not([data-scamshield-scanned="true"])
    `);

    messageElements.forEach(el => {
      // Telegram nests these classes; scan only one element per message
      if (el.closest('[data-scamshield-scanned="true"]') || el.querySelector('[data-scamshield-scanned="true"]')) {
        el.setAttribute("data-scamshield-scanned", "true");
        return;
      }
      el.setAttribute("data-scamshield-scanned", "true");

      // Skip outgoing messages if marked
      if (el.classList.contains("is-out") || el.closest(".is-out") || el.classList.contains("own")) {
        return;
      }

      const text = el.innerText?.trim();
      if (!text || text.length < 8) return;

      chrome.runtime.sendMessage(
        {
          type: "SCAN_CHAT",
          payload: { text, platform: "telegram" }
        },
        (response) => {
          if (chrome.runtime.lastError) return;
          if (response && !response.offline && response.threat_score >= 35) {
            injectTacticalPill(el, response);
          }
        }
      );
    });
  }

  // ---------------------------------------------------------------------------
  // Facebook Marketplace & Messenger Parser
  // ---------------------------------------------------------------------------
  function scanFacebookAndMessenger() {
    const hostname = window.location.hostname;
    const isSandbox = Boolean(document.querySelector("[data-scamshield-sandbox]") || window.location.href.includes("sandbox"));
    if (!hostname.includes("facebook.com") && !hostname.includes("messenger.com") && !isSandbox) return;

    // 1. Messenger Active Chat Bubbles
    const chatBubbles = document.querySelectorAll(`
      div[role="row"] div[dir="auto"]:not([data-scamshield-scanned="true"]),
      div[data-testid="message-container"]:not([data-scamshield-scanned="true"])
    `);

    chatBubbles.forEach(bubble => {
      bubble.setAttribute("data-scamshield-scanned", "true");
      const text = bubble.innerText?.trim();
      if (!text || text.length < 8) return;

      chrome.runtime.sendMessage(
        {
          type: "SCAN_CHAT",
          payload: { text, platform: "messenger" }
        },
        (response) => {
          if (chrome.runtime.lastError) return;
          if (response && !response.offline && response.threat_score >= 35) {
            injectTacticalPill(bubble, response);
          }
        }
      );
    });

    // 2. Facebook Marketplace Listing Cards & Feeds
    const listingCards = document.querySelectorAll(`
      div[role="feed"] a[href*="/marketplace/item/"]:not([data-scamshield-scanned="true"]),
      div[role="main"] a[href*="/marketplace/item/"]:not([data-scamshield-scanned="true"]),
      .marketplace-listing-card:not([data-scamshield-scanned="true"])
    `);

    listingCards.forEach(card => {
      card.setAttribute("data-scamshield-scanned", "true");
      const cardText = card.innerText || "";
      
      // Parse rough price if available (e.g., $120 or $1,200)
      const priceMatch = cardText.match(/\$([0-9,]+)/);
      let price = 0;
      if (priceMatch) {
        price = parseFloat(priceMatch[1].replace(/,/g, ""));
      }

      // Seller age / market price are unknown on feed cards: use neutral defaults instead of guessing
      const sellerAge = card.hasAttribute("data-seller-age") ? parseInt(card.getAttribute("data-seller-age"), 10) : 12;
      const parsedPrice = card.hasAttribute("data-price") ? parseFloat(card.getAttribute("data-price")) : price;
      const marketAvg = card.hasAttribute("data-market-avg") ? parseFloat(card.getAttribute("data-market-avg")) : parsedPrice;
      const shipsOnly = cardText.toLowerCase().includes("shipping only") || cardText.toLowerCase().includes("ships to you") || card.getAttribute("data-ships-only") === "true";

      // Check for courier or external payment triggers directly in card preview
      chrome.runtime.sendMessage(
        {
          type: "SCAN_MARKETPLACE",
          payload: {
            account_age_months: sellerAge,
            price: parsedPrice,
            market_avg: marketAvg,
            description: cardText,
            ships_only: shipsOnly
          }
        },
        (response) => {
          if (chrome.runtime.lastError) return;
          if (response && !response.offline && response.risk_score >= 45) {
            injectTacticalPill(card, {
              threat_score: response.risk_score,
              threat_level: response.threat_level,
              advisory: response.recommendation,
              detected_vectors: (response.anomalies || []).map(a => ({ vector: "MARKETPLACE_ANOMALY", score: response.risk_score, indicators: [a] })),
              flagged_phrases: []
            });
          }
        }
      );
    });
  }

  // ---------------------------------------------------------------------------
  // Master Debounced DOM Observer Loop
  // ---------------------------------------------------------------------------
  let debounceTimer = null;

  function runThreatScanCycle() {
    scanTelegramMessages();
    scanFacebookAndMessenger();
    attachCreditCardTrapListeners();
  }

  const observer = new MutationObserver(() => {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(runThreatScanCycle, 300);
  });

  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true
  });

  // Initial Scan Run
  runThreatScanCycle();

  // ---------------------------------------------------------------------------
  // Message Listener for Tab Updates from Background
  // ---------------------------------------------------------------------------
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "TAB_THREAT_UPDATED") {
      currentTabTelemetry = message.data;
    }
  });

  // Query background for existing tab security context on load
  chrome.runtime.sendMessage({ type: "GET_TAB_TELEMETRY" }, (response) => {
    if (chrome.runtime.lastError) return;
    if (response) {
      currentTabTelemetry = response;
    }
  });
})();
