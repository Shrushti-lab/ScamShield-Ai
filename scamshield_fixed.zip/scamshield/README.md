# ScamShield AI - Enterprise Threat Interceptor & Security Suite

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-green.svg)](https://fastapi.tiangolo.com)
[![Chrome MV3](https://img.shields.io/badge/Chrome%20Extension-Manifest%20V3-orange.svg)](https://developer.chrome.com/docs/extensions/mv3/)
[![Model Optimization](https://img.shields.io/badge/Optimizer-Grey%20Wolf%20(GWO)-purple.svg)](#grey-wolf-optimizer-gwo)

**ScamShield AI** is an enterprise-grade real-time cybersecurity defense suite and Chromium browser extension. It intercepts and neutralizes:
1. **Facebook Marketplace Scams**: Fake courier pickups ("my son will pick up"), overpayment checks, off-platform payment diversions (Zelle, Venmo, CashApp), 6-digit OTP code exfiltration, and new burner accounts.
2. **Deceptive E-Commerce Webstores**: Homoglyph lookalikes, punycode visual spoofing (`xn--`), high Shannon entropy domains, unauthenticated credit card form harvesters, and suspicious top-level domains (`.xyz`, `.top`, `.tk`, `.buzz`).
3. **Telegram Web Fraud (`web.telegram.org/a/` and `/k/`)**: Crypto task rating fraud, fake daily guaranteed ROI, pump-and-dump signals, impersonation support bots, and malicious wallet drainer links.

---

> **Note on metrics:** the benchmark scores below (1.0000) come from a synthetic, template-generated dataset and show the pipeline works; they are not a real-world accuracy claim. Retrain on real phishing feeds (e.g. PhishTank / OpenPhish) before relying on them.

---

## 🏛️ System Architecture

```
                    ┌────────────────────────────────────────────────────────┐
                    │                   BROWSER SURFACES                     │
                    │  Telegram Web (A/K)  |  Facebook Marketplace  |  Web  │
                    └───────────────────────────┬────────────────────────────┘
                                                │
                     DOM MutationObserver (300ms debounce) & Input Listeners
                                                │
                                                ▼
┌────────────────────────────────────────────────────────────────────────────────────────────┐
│                       CHROME EXTENSION (MANIFEST V3 SANDBOX)                                │
│                                                                                            │
│   ┌───────────────────────────┐     Closed Shadow DOM      ┌───────────────────────────┐   │
│   │  content.js               │ ─────────────────────────> │ Injected Security Pills   │   │
│   │  • Telegram A/K Parser    │     Zero Style Bleed       │ & CC Harvester Trap Modal │   │
│   │  • FB Marketplace Parser  │                            └───────────────────────────┘   │
│   │  • Credit Card Interceptor│                                                            │
│   └─────────────┬─────────────┘                                                            │
│                 │ runtime.sendMessage                                                      │
│                 ▼                                                                          │
│   ┌───────────────────────────┐      chrome.action         ┌───────────────────────────┐   │
│   │  background.js            │ ─────────────────────────> │ Dynamic Color Badge       │   │
│   │  • MV3 Service Worker     │                            │ (SAFE: Green, WARN: Amber,│   │
│   │  • Tab URL State Tracking │                            │  DGR: Red with score)     │   │
│   └─────────────┬─────────────┘                            └───────────────────────────┘   │
│                 │                                                                          │
│                 │ chrome.runtime (GET_TAB_TELEMETRY)                                       │
│                 ▼                                                                          │
│   ┌────────────────────────────────────────────────────────────────────────────────────┐   │
│   │  popup/ (Cyberpunk HUD: popup.html, popup.css, popup.js)                           │   │
│   │  • SVG Radial Threat Gauge (0-100%)                                                │   │
│   │  • Live Telemetry Meters (Entropy, Confidence, Payment Trap, Latency)              │   │
│   │  • Real-time Manual Threat Scanner & GWO-RF Benchmark Matrix                       │   │
│   └────────────────────────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────┬────────────────────────────────────────────────────┘
                                        │
                               HTTP REST (CORS)
                                        │
                                        ▼
┌────────────────────────────────────────────────────────────────────────────────────────────┐
│                         FASTAPI BACKEND SERVICE (PORT 8000)                                │
│                                                                                            │
│   ┌─────────────────────────────────┐           ┌──────────────────────────────────────┐   │
│   │  DomainLRUCache (OrderedDict)   │ ◄───────► │  POST /api/v1/scan-url               │   │
│   │  Sub-millisecond repeat queries │           │  • 16-Dimensional Feature Extraction │   │
│   └─────────────────────────────────┘           │  • GWO-Tuned Random Forest Inference │   │
│                                                 └──────────────────────────────────────┘   │
│   ┌─────────────────────────────────┐           ┌──────────────────────────────────────┐   │
│   │  Threat Heuristics Engine       │ ◄───────► │  POST /api/v1/scan-chat              │   │
│   │  • OTP 6-Digit Harvesting       │           │  POST /api/v1/scan-marketplace       │   │
│   │  • Off-Platform Payment Pivots  │           └──────────────────────────────────────┘   │
│   │  • Urgency & Financial Coercion │           ┌──────────────────────────────────────┐   │
│   │  • Crypto Task / Drainer Fraud  │ ◄───────► │  GET  /api/v1/model-metrics          │   │
│   │  • Price Deviation & Courier    │           │  GET  /api/v1/health                 │   │
│   └─────────────────────────────────┘           └──────────────────────────────────────┘   │
└────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🧮 Mathematical Rigor: Grey Wolf Optimizer (GWO)

The URL classifier is optimized using a custom **Grey Wolf Optimizer (GWO)** implemented from scratch in `app/ml_engine.py`. GWO models the leadership hierarchy and hunting mechanism of grey wolves:

### 1. Leadership Hierarchy
- **Alpha ($\alpha$)**: The dominant decision-maker vector representing the best solution discovered so far.
- **Beta ($\beta$)**: The second-in-command assisting the Alpha.
- **Delta ($\delta$)**: The third-in-command scouts and sentinels.
- **Omega ($\omega$)**: The remaining wolf population guided by $\alpha, \beta, \delta$.

### 2. Search Space Boundaries
Hyperparameter search space for the Random Forest classifier:
$$\text{Lower Bound (lb)} = [50, 5, 2] \quad \le \quad [n\_estimators, max\_depth, min\_samples\_split] \quad \le \quad [300, 30, 10] = \text{Upper Bound (ub)}$$

### 3. Position Update Equations
For each iteration $t$:
$$a = 2 - 2 \cdot \left(\frac{t}{\text{max\_iter}}\right)$$
$$A_1 = 2a \cdot r_1 - a, \quad C_1 = 2r_2 \quad (r_1, r_2 \sim \mathcal{U}(0,1))$$
$$D_\alpha = |C_1 \alpha - X|, \quad X_1 = \alpha - A_1 D_\alpha$$
$$D_\beta = |C_2 \beta - X|, \quad X_2 = \beta - A_2 D_\beta$$
$$D_\delta = |C_3 \delta - X|, \quad X_3 = \delta - A_3 D_\delta$$
$$X(t+1) = \frac{X_1 + X_2 + X_3}{3}$$

### 4. Objective Fitness Function
The wolves optimize the **Matthews Correlation Coefficient (MCC)** to handle class imbalance rigorously:
$$\text{MCC} = \frac{TP \times TN - FP \times FN}{\sqrt{(TP + FP)(TP + FN)(TN + FP)(TN + FN)}}$$
$$\text{Fitness} = \text{MCC}(y_{\text{val}}, \hat{y})$$

---

## 🔬 16-Dimensional URL Feature Extractor

Every inspected URL is parsed into a 16-dimensional continuous feature vector:

| # | Feature Name | Computation Formula / Logic |
|---|---|---|
| 1 | `url_length` | Total character length $\text{len}(u)$ |
| 2 | `domain_length` | Total character length of hostname |
| 3 | `domain_shannon_entropy` | $H = -\sum_{i=1}^n p(x_i) \log_2 p(x_i)$ on hostname characters |
| 4 | `subdomain_depth` | Subdomain segment count: $\max(0, \text{labels} - 2)$ |
| 5 | `is_ip_address` | Binary flag ($1$ if matches IPv4 `\d+\.\d+\.\d+\.\d+` or IPv6, else $0$) |
| 6 | `punycode_flag` | Binary flag ($1$ if contains `xn--` homoglyph encoding, else $0$) |
| 7 | `symbol_ratio` | $\text{count}(\text{non-alphanumeric}) / \text{len}(u)$ |
| 8 | `digit_ratio` | $\text{count}(\text{digits}) / \text{len}(u)$ |
| 9 | `suspicious_tld_score` | Binary flag for high-abuse TLDs (`.xyz`, `.top`, `.tk`, `.buzz`, `.club`, `.work`, etc.) |
| 10 | `min_levenshtein_brand` | Dynamic programming Levenshtein distance to target brands (`paypal`, `amazon`, `chase`, etc.) |
| 11 | `brand_with_hyphen_flag` | Flag for deceptive brand tokens (e.g. `paypal-security`, `amazon-update`) |
| 12 | `path_depth` | Directory segment count in URL path |
| 13 | `query_length` | Character length of URL query parameters |
| 14 | `suspicious_keyword_flag` | Flag for security lures (`verify`, `wallet`, `claim`, `login`, `airdrop`, etc.) |
| 15 | `has_custom_port` | Binary flag ($1$ if port explicitly specified and $\ne 80, 443$) |
| 16 | `double_slash_redirect` | Binary flag ($1$ if `//` exists in path for open-redirect evasion) |

---

## 📊 Benchmark Matrix

Comparative performance matrix across 4,200 labeled URL samples (Alexa/Tranco top domains vs brand typosquats, DGA, homoglyphs, and IP hosts):

```
================================================================================
                     SCAMSHIELD AI - MODEL BENCHMARK MATRIX
================================================================================
Classifier               | Accuracy   | Precision  | Recall     | F1 Score   | MCC     
--------------------------------------------------------------------------------
Decision_Tree            | 1.0000     | 1.0000     | 1.0000     | 1.0000     | 1.0000  
Linear_SVM               | 0.9937     | 0.9937     | 0.9937     | 0.9937     | 0.9873  
GWO_Random_Forest        | 1.0000     | 1.0000     | 1.0000     | 1.0000     | 1.0000  
================================================================================
 [GWO] GREY WOLF OPTIMIZER CONVERGENCE SUMMARY:
  - Optimal n_estimators    : 144
  - Optimal max_depth       : 29
  - Optimal min_samples_split: 8
  - Optimization Time        : 22.29s
================================================================================
```

---

## 🛡️ Threat Vector Coverage Catalog

### 1. Verification Code / OTP Exfiltration
- **Pattern**: Attacker requests a phone number, initiates a Google Voice / 2FA setup, and demands the recipient send the 6-digit code under the guise of "proving you are a real person."
- **Detection**: Regex token exfiltration analysis, 6-digit PIN detection, social engineering challenge matching.
- **Interception**: Injects a closed Shadow DOM tactical warning banner directly under the chat bubble: `[SCAMSHIELD: ⚠️ OTP THEFT DETECTED - DO NOT SEND CODE]`.

### 2. Off-Platform Payment Pivots & Courier Scams
- **Pattern**: Buyer agrees to purchase immediately without negotiation, claims they are "out of town," states "my son / courier will pick it up," and insists on sending payment via Zelle / Venmo with a fake overpayment or "commercial upgrade fee."
- **Detection**: Named-entity payment keywords (`zelle`, `venmo`, `cashapp`, `wire`), family proxy pickup cues (`my son will pick up`), overpayment lures.

### 3. Credit Card Harvester Trap
- **Pattern**: Deceptive checkout page collects payment card credentials on an untrusted domain.
- **Interception**: `content.js` monitors payment input fields (`input[autocomplete*="cc-"]`, `input[name*="card"]`, `input[name*="cvv"]`). When focused on an untrusted or high-threat domain, it triggers a fullscreen closed Shadow DOM warning modal and synthesizes a Web Audio alarm tone before the user can submit credentials.

### 4. Telegram Crypto Task & Pump-and-Dump Fraud
- **Pattern**: Automated bots or recruitment agents in Telegram Web (A or K) offering guaranteed daily ROI, YouTube video liking tasks for USDT commissions, or wallet-drainer connect links.
- **Detection**: Token analysis for `daily roi`, `recharge usdt`, `vip signals`, `task bonus`, `double your crypto`.

---

## 🚀 Quickstart & Setup Guide

### 1. Environment Setup

```bash
# Clone or navigate to the repository
cd scamshield

# Install Python dependencies
pip install -r requirements.txt
```

### 2. Generate Dataset & Train GWO-RF Model

```bash
# Generate 4,200+ URL samples and 1,200+ chat transcripts
python scripts/build_dataset.py

# Run Grey Wolf Optimizer hyperparameter tuning and model training
python scripts/train_model.py
```

### 3. Run Automated Integration Test Suite

```bash
# Execute pytest integration test suite (covers all endpoints and edge cases)
pytest -v scripts/test_api.py
```

### 4. Start the FastAPI Threat Interception Server

```bash
# Launch high-throughput API service on port 8000
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Server interactive documentation will be available at:
- Swagger UI: `http://127.0.0.1:8000/docs`
- Redoc: `http://127.0.0.1:8000/redoc`

---

## 🌐 Loading the Extension in Google Chrome / Brave / Edge

1. Open your Chromium browser and navigate to `chrome://extensions`.
2. Enable **Developer mode** toggle in the top-right corner.
3. Click the **Load unpacked** button in the top-left toolbar.
4. Select the `extension/` directory from this repository:
   ```
   c:\Users\mihir\scamshield\extension\
   ```
5. Pin the **ScamShield AI** extension to your toolbar.
6. The Cyberpunk HUD will display real-time security posture, active tab entropy, and allow manual threat scanning.

---

## 📡 API Endpoint Reference

### 1. `POST /api/v1/scan-url`
Analyzes a URL using the 16-feature GWO-RF pipeline with sub-millisecond LRU caching.

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/scan-url" \
  -H "Content-Type: application/json" \
  -d '{"url": "http://paypal-security-verification.xyz/login.php?user=claim"}'
```

**Response**:
```json
{
  "url": "http://paypal-security-verification.xyz/login.php?user=claim",
  "is_phishing": true,
  "threat_score": 100.0,
  "confidence": 1.0,
  "entropy": 3.737,
  "risk_factors": [
    "High-risk top-level domain frequently associated with abuse.",
    "Brand name combined with deceptive hyphenated token.",
    "Suspicious credential or financial lure keywords found in URL."
  ],
  "features": {
    "url_length": 62.0,
    "domain_length": 34.0,
    "domain_shannon_entropy": 3.737,
    "subdomain_depth": 0.0,
    "is_ip_address": 0.0,
    "punycode_flag": 0.0,
    "symbol_ratio": 0.161,
    "digit_ratio": 0.0,
    "suspicious_tld_score": 1.0,
    "min_levenshtein_brand": 0.0,
    "brand_with_hyphen_flag": 1.0,
    "path_depth": 1.0,
    "query_length": 10.0,
    "suspicious_keyword_flag": 1.0,
    "has_custom_port": 0.0,
    "double_slash_redirect": 0.0
  },
  "advisory": "CRITICAL: Do NOT enter credentials or payment data. Strong indicators of phishing or spoofing.",
  "cached": false,
  "latency_ms": 1.15
}
```

---

### 2. `POST /api/v1/scan-chat`
Evaluates message text for OTP exfiltration, off-platform payment diversions, urgency coercion, and crypto task fraud.

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/scan-chat" \
  -H "Content-Type: application/json" \
  -d '{"text": "I sent a 6-digit Google Voice verification code to your phone. Send me the code to prove you are real.", "platform": "telegram"}'
```

**Response**:
```json
{
  "text": "I sent a 6-digit Google Voice verification code to your phone. Send me the code to prove you are real.",
  "platform": "telegram",
  "threat_score": 100.0,
  "threat_level": "CRITICAL",
  "detected_vectors": [
    {
      "vector": "OTP_VERIFICATION_THEFT",
      "score": 100.0,
      "description": "Attempting to harvest 2FA/SMS/Google Voice verification codes to hijack accounts.",
      "indicators": [
        "Explicit OTP / Verification code lure",
        "Direct code exfiltration attempt",
        "Social engineering identity challenge pretext",
        "Code delivery notification trigger"
      ]
    }
  ],
  "flagged_phrases": [
    "send me the code",
    "google voice",
    "prove you are real",
    "6-digit code"
  ],
  "vector_count": 1,
  "advisory": "HIGH THREAT: Do NOT comply, send codes, or execute payments. Immediately block and report this sender."
}
```

---

### 3. `POST /api/v1/scan-marketplace`
Combines listing pricing anomaly heuristics with seller account tenure and NLP description analysis.

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/scan-marketplace" \
  -H "Content-Type: application/json" \
  -d '{
    "account_age_months": 1,
    "price": 250.0,
    "market_avg": 1100.0,
    "description": "Brand new MacBook. My son will pick up tomorrow. Pay via Zelle.",
    "ships_only": true
  }'
```

---

### 4. `GET /api/v1/model-metrics`
Returns comparative accuracy, precision, recall, F1-score, and MCC benchmarks across models, with optimal GWO hyperparameter vectors.

---

### 5. `GET /api/v1/health`
Returns real-time server health, model loaded status, uptime, and LRU cache hit/miss telemetry.

---

## 🔒 Security & Privacy Considerations

- **Closed Shadow DOM**: All injected warning badges use `attachShadow({ mode: 'closed' })`. This prevents malicious or inquisitive host page scripts from reading, altering, or hiding warning notifications.
- **Client-Side Fallbacks**: If the backend server is temporarily paused, `background.js` and `popup.js` seamlessly fall back to local heuristics so user browsing protection is never disrupted.
- **Zero Third-Party Telemetry**: ScamShield AI runs entirely locally. No chat messages or browsing URLs are dispatched to third-party tracking services or external cloud providers.
